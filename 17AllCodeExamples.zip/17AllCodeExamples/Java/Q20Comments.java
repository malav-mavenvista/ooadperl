//Improve the code
class InchToPointConvertor {
    //convert the quantity in inches to points.
    static float parseInch(float inch) {
        return inch * 72; //one inch contains 72 points.
    }
}
