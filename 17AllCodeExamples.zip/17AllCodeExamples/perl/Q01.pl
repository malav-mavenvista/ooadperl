use 5.026;
use warnings;
use utf8;

package StringUtils {
    use Moose;
    sub is_same_string {
        my ( $self, $s1, $s2 ) = @_;
        return 1 if ( !defined $s1 ) && ( !defined $s2 );
        return 0 if ( !defined $s1 );
        return  $s1 eq $s2;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Order {
    use Moose;
    use StringUtils;
    #Some attributes and methods here.

    sub is_same_string {
        my ( $self, $s1, $s2 ) = @_;
        StringUtils->new()->is_same_string($s1, $s2);
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Mail {
    use Moose;

    #Some attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $o = Order->new();
ok( $o->is_same_string( 'a', 'a' ), 'Same string for Order' );
my $m = Mail->new();
done_testing();
1;