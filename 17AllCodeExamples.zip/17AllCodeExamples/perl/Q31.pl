use 5.026;
use warnings;
use utf8;

package UserAccount {
    use Moose;
    use DateTime;

    use constant {
        USERTYPE_NORMAL => 0,
        USERTYPE_ADMIN  => 1,
        USERTYPE_GUEST  => 2
    };
    has 'user_type' => ( is => 'ro', isa => 'Int', required => 1 );

    has 'id'       => ( is => 'ro', isa => 'Str', required => 1 );
    has 'name'     => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'password' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'date_of_last_password_change' => (
        is      => 'rw',
        isa     => 'DateTime',
        default => sub { DateTime->today() },
    );

    sub check_password {
        my ( $self, $password ) = @_;
        #...
        return    #True if password correct.
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Inventory {
    use Moose;
    use DateTime;
    use Carp;

    sub login {
        my ( $self, $user_logging_in, $password ) = @_;
        if ( $user_logging_in->check_password($password) ) {
            my $today = DateTime->today();
            my $expiry_date = $self->get_account_expiry_date($user_logging_in);
            if ( DateTime->compare( $today, $expiry_date ) > 0 ) {
                #prompt user to change password here
            }
        }
        return $self;
    }

    sub get_account_expiry_date {
        my ( $self, $account ) = @_;
        my $password_max_age_in_days = $self->get_password_max_age_in_days($account);
        return $account->date_of_last_password_change->clone()
            		->add( days => $password_max_age_in_days );
    }

    sub get_password_max_age_in_days {
        my ( $self, $account ) = @_;
        return 90 if $account->user_type == UserAccount::USERTYPE_NORMAL;
        return $account->user_type == UserAccount::USERTYPE_ADMIN ? 30 : 10_000;
    }

    sub print_report {
        my ( $self, $current_user ) = @_;
        my $can_print = do {
            if ( $current_user->user_type == UserAccount::USERTYPE_GUEST ) {0}
            else                                                           {1}
        };
        $can_print == 1 || confess('You have no right');
        #print the report here
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $un = UserAccount->new( user_type => UserAccount::USERTYPE_NORMAL, id => 'v' );
my $app = Inventory->new();
is( $app->login( $un, q{} ), $app );
is( $app->print_report($un), $app );
done_testing();
1;
