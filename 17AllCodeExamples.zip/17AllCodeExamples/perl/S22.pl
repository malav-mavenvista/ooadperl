use 5.026;
use warnings;
use utf8;

package Account {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub is_complex_password ( $self, $password ) {
        return $self->contains_letter($password)
            && ( $self->contains_digit($password) || $self->contains_symbol($password) );
    }

    sub contains_letter ( $self, $password ) {
        #...
    }

    sub contains_digit ( $self, $password ) {
        #...
    }

    sub contains_symbol ( $self, $password ) {
        #...
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $a = Account->new();
$a->is_complex_password('A1');
done_testing();
1;
