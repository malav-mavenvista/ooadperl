use 5.026;
use warnings;
use utf8;

# This application is about students. Originally we had a
# simple Student class:
#	package Student {
#		...
#		has 'student_id' => (is=>'ro', isa=>'Str', required=>1);
#		has 'name' => (is=>'ro', isa=>'Str', required=>1);
#		has 'date_of_birth' => (is=>'ro', isa=>'DateTime', required=>1);
#		...
#   }
# Later, in order to record what courses the student has
# enrolled in, on which dates he enrolled and how he paid for them,
# we modified the code as shown below.
# Your task is to implement this requirement without modifying
# the original Student class.

package CourseDetails {
    use Moose;
    use DateTime;
    has 'course_code' =>  
        ( is => 'ro', isa => 'Str', default => q{} );
    has 'enroll_date' =>
        ( is => 'ro', isa => 'DateTime', required=>1 );
    has 'payment' =>  
        ( is => 'ro', isa => 'Num', default => 0 );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}


package StudentCourses {
        use Moose;

      has 'courses_enrolled_for' =>  
        ( is => 'ro', isa => 'HashRef[CourseDetails]', default => sub { {} } );
      sub enroll {
        my ( $self, $course_details ) = @_;

        #Add $course_code to $self->course_codes
        #Add $enroll_date to $self->enroll_dates
        #Add $payment to $self->payments
        return $self;
    }

    sub unenroll {
        my ( $self, $course_code ) = @_;
        #...
        return $self;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}
package Student {
    use Moose;
    use DateTime;

    has 'student_id'    => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'name'          => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'date_of_birth' => ( is => 'ro', isa => 'DateTime', required => 1 );
   

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package StudentManagementSystem {
    use Moose;
    use DateTime;
    use StudentCourses;

    has '_students' =>
        ( is => 'ro', isa => 'ArrayRef[Student]', default => sub { [] } );
    has 'student_courses' =>
        ( is => 'ro', isa => 'StudentCourses', default => sub { StudentCourses->new() } );

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $s = Student->new(
    student_id    => 1,
    name          => 'Vijay',
    date_of_birth => DateTime->now
);
ok( defined $s, 'Student created' );
done_testing();
1;
