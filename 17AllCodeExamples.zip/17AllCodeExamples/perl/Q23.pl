use 5.026;
use warnings;
use utf8;

#Improve the code
package TokenStream {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'v' => ( is => 'rw', isa => 'ArrayRef[Str]', default => sub { [] } )
        ;    #a list of tokens parsed from br.
    has 'index' => ( is => 'rw', isa => 'Int', default => 0 )
        ;    #index of the current token in v.
    has 'br' => ( is => 'ro', isa => 'BufferedReader', required => 1 )
        ;    #read the chars from here to parse the tokens.
    has 'current_char' => ( is => 'rw', isa => 'Int', default => 0 )
        ;    #previous char read from br.

    #read the chars from the reader and parse the tokens.
    sub BUILD ( $self, $args ) {
        $self->take_char();
        $self->v( $self->parse_file() );
    }

    sub take_char($self) {
        #....
    }

    #read the chars from br, parse the tokens and store them into an List
    sub parse_file($self) {
        my $v = [];    #accumulate the tokens that have been parsed.
        #...
        return $v;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package BufferedReader { #Dummy class
    use Moose;
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
TokenStream->new( br => BufferedReader->new() );
done_testing();
1;
