package Point;
use 5.026;
use utf8;
use Moose;
use MooseX::StrictConstructor;

with 'IEquals';

has 'x' => ( is => 'ro', isa => 'Int', required => 1 );
has 'y' => ( is => 'ro', isa => 'Int', required => 1 );

sub to_string {
    my $self = shift;
    return sprintf '(x=%d, y=%d)', $self->x, $self->y;
}

sub equals {
    my $self  = shift;
    my $other = shift;
    return 1 if $self == $other;
    return 0 if ref $other ne ref $self;
    return ( $self->x == $other->x ) && ( $self->y == $other->y );
}

no Moose;
__PACKAGE__->meta->make_immutable;
1;
