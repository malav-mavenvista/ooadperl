package IEquals;
use 5.026;
use utf8; 
use Moose::Role; 
requires  'equals';
no Moose::Role;
__PACKAGE__
