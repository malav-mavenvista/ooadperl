use 5.026;
use warnings;
use utf8;

package ICourses {
    use Moose::Role;
    requires 'get_courses_in_subject';
    no Moose::Role;
    1;
}

#Database logic
package CoursesInDB {
    use Moose;
    use Try::Tiny;
    with 'ICourses';
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'courses' =>
        ( is => 'ro', isa => 'ArrayRef[Course]', default => sub { [] } );

    sub get_courses_in_subject ( $self, $subj_area ) {
        my $db_conn = DbConnection->new();
        my $st      = $db_conn->prepare_statement(
            'select * from courses where subjArea=?');
        try {
            $st->set_string( 1, $subj_area );
            my $rs = $st->execute_query();
            try {
                while ( $rs->next ) {
                    my $course = Course->new(
                        course_code => $rs->get_string(1),
                        course_name => $rs->get_string(2),
                        course_fee  => $rs->get_int(3)
                    );
                    push @{ $self->courses }, $course;
                }
            }
            finally {
                $rs->close();
            };
        }
        finally {
            $st->close();
        };
        return $self->courses;
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ShowCoursesServlet {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub do_get ( $self, $request, $response ) {
        $response->content_type('text/html');
        my $out = $response->writer();
        $out->println('<HTML><TITLE>Course listing</TITLE><BODY>');
        my $courses            = CoursesInDB->new();
        my $courses_in_subject = $courses->get_courses_in_subject(
            $request->get_parameter('subjArea') );
        $out->println('<Table>');
        foreach my $course ( @{$courses_in_subject} ) {
            $out->println('<TR>');
            $out->println('<TD>');
            $out->println( $course->course_code );
            $out->println('</TD>');
            $out->println('<TD>');
            $out->println( $course->course_name );    #course name
            $out->println('</TD>');
            $out->println('<TD>');
            $out->println( $course->course_fee );
            $out->println('</TD>');
            $out->println('</TR>');
        }
        $out->println('</body></html>');
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Course {
    use Moose;
    has 'course_code' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'course_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'course_fee'  => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

#Empty classes for running script
package Request {
    use Moose;
    sub get_parameter {' '}
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Response {
    use Moose;
    has 'content_type' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'writer'       => (
        is      => 'rw',
        isa     => 'PrintWriter',
        default => sub { PrintWriter->new() }
    );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PrintWriter {
    use Moose;
    sub println { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package DbConnection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string    { }
    sub execute_query { ResultSet->new() }
    sub close         { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package ResultSet {
    use Moose;
    sub next       {0}
    sub get_string {' '}
    sub get_int    {0}
    sub close      { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
ShowCoursesServlet->new()->do_get( Request->new, Response->new );
done_testing();
1;
