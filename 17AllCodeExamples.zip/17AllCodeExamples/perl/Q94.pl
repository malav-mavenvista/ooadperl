use 5.026;
use warnings;
use utf8;

 # This application is about courses. A course has a course code,
 # a title, a fee and a number of sessions. A session specifies
 # a date, a starting hour and ending hour. You have also created the
 # following classes:
package Course {
	use Moose;
	has 'course_id' => (is=>'rw', isa=>'Str', default=>q{});
	has 'title' => (is=>'rw', isa=>'Str', default=>q{});
	has 'fee' => (is=>'rw', isa=>'Int', default=>0);
	has 'sessions' => (is=>'ro', isa=>'ArrayRef[Session]', default=>sub{[]});
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package  Session {
	use Moose;
	use DateTime;
	has 'date' => (is=>'rw', isa=>'DateTime');
	has 'start_hour' => (is=>'rw', isa=>'Int', default=>0);
	has 'end_hour' => (is=>'rw', isa=>'Int', default=>0);
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

#The DBA (database administator) has created the tables below:
#create table Courses ( courseId varchar(20) primary key,
#    title varchar(20) not null, fee int not null);
#create table Sessions ( courseId varchar(20), sessionId int,
#    sessionDate date not null,startHour int not null,
#    endHour int not null,primary key(courseId, sessionId)
#);
#
#Your tasks are:
#1. Create an interface for accessing the courses while hiding the database.
#2. Create a class to implement that interface and show how to implement
#   its method for adding a course to the database.
#3. Give outline of its method for enumerating all courses whose total duration
#   is greater than a specified number of hours.


use Test::More;
Session->new();
Course->new();
done_testing();
1;