use 5.026;
use warnings;
use utf8;

package Employee {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'id'       => ( is => 'ro', isa => 'Int',     default  => 0 );
    has 'name'     => ( is => 'rw', isa => 'Str',     default  => q{} );
    has 'address'  => ( is => 'rw', isa => 'Str',     default  => q{} );
    has 'mobile'   => ( is => 'ro', isa => 'Str',     default  => q{} );
    has '_holiday' => ( is => 'ro', isa => 'CodeRef', required => 1 );

    sub calculate_holidays_permitted ( $self, $month ) {
        return $self->_holiday->($month);
    }

    sub calculate_holidays_permitted_for_permanent ( $unused, $month ) {
        return ( $month == 12 ) ? 4 : 3;
    }

    sub calculate_holidays_permitted_for_temporary ( $unused, $month ) {
        return 2;
    }

    sub create_permanent_employee($unused) {
        return Employee->new(
            _holiday => sub {
                __PACKAGE__->calculate_holidays_permitted_for_permanent(@_);
            }
        );
    }

    sub create_temporary_employee($unused) {
        return Employee->new(
            _holiday => sub {
                __PACKAGE__->calculate_holidays_permitted_for_temporary(@_);
            }
        );
    }

    #Some functions here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
is( Employee->create_permanent_employee->calculate_holidays_permitted(1), 3 );
is( Employee->create_temporary_employee->calculate_holidays_permitted(2), 2 );
done_testing();
1;
