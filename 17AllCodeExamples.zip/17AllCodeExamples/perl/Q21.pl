use 5.026;
use warnings;
use utf8;

#Improve the code
package Badge {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'pid'      => ( is => 'ro', isa => 'Str', required => 1 );
    has 'eng_name' => ( is => 'rw', isa => 'Str', default  => q{} )
        ;    #participant's full name in English
    has 'chi_name' => ( is => 'rw', isa => 'Str', default => q{} )
        ;    #participant's full name in Chinese
    has 'eng_org_name' => ( is => 'rw', isa => 'Str', default => q{} )
        ;    #name of the participant's organization in English
    has 'chi_org_name' => ( is => 'rw', isa => 'Str', default => q{} )
        ;    #name of the participant's organization in Chinese
    has 'eng_country' => ( is => 'rw', isa => 'Str', default => q{} )
        ;    #the organization's country in English
    has 'chi_country' => ( is => 'rw', isa => 'Str', default => q{} )
        ;    #the organization's country in Chinese

    #The participant ID is provided. It then loads all the info from the DB.
    sub BUILD ( $self, $args ) {
        #get the participant's full names.
        my $parts_in_db = ParticipantsInDB->new();
        my $part        = $parts_in_db->locate_participant( $self->pid );
        if ( defined $part ) {
            #get the participant's full name in English.
            $self->eng_name("$part->e_last_name, $part->e_first_name");

            #get the participant's full name in Chinese.
            $self->chi_name( $part->c_last_name . $part->c_first_name );

            #get the organization's name and country.
            my $orgs_in_db = OrganizationsInDB->new();

            #find the ID of the organization employing this participant.
            my $oid = $orgs_in_db->get_organization( $self->pid );
            if ( defined $oid ) {
                my $org = $orgs_in_db->locate_organization($oid);
                $self->eng_org_name( $org->e_name );
                $self->chi_org_name( $org->c_name );
                $self->eng_country( $org->e_address->country );
                $self->chi_country( $org->c_address->country );
            }
        }
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

#dummy classes to run above code
package ParticipantsInDB {
    use Moose;
    sub locate_participant { Participant->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package OrganizationsInDB {
    use Moose;
    sub get_organization    {'org'}
    sub locate_organization { Organization->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Participant {
    use Moose;
    has 'e_last_name'  => ( is => 'rw', isa => 'Str', default => q{} );
    has 'e_first_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_last_name'  => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_first_name' => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Address {
    use Moose;
    has 'country' => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Organization {
    use Moose;
    has 'e_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'e_address' =>
        ( is => 'rw', isa => 'Address', default => sub { Address->new() } );
    has 'c_address' =>
        ( is => 'rw', isa => 'Address', default => sub { Address->new() } );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
#end of dummy classes

use Test::More;
Badge->new( pid => '1' );
done_testing();
1;
