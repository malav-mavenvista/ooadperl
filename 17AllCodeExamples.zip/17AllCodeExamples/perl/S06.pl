use 5.026;
use warnings;
use utf8;

package ReportCatalogueIndexCommandParser {
    use Moose;
    use MooseX::ClassAttribute;
    use Try::Tiny;
    use HashMap;
    use String;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant {
        ORG_CATALOG  => 0,
        PART_CATALOG => 1,
        #....  other codes
    };
    class_has '_catalog_codes' => (
        is      => 'ro',
        isa     => 'HashMap',
        lazy    => 1,
        builder => '_initialize_catalog_codes',
    );

    sub _initialize_catalog_codes {
        return HashMap->new()
            ->put( String->new( value => 'orgNoGrouping' ), ORG_CATALOG )
            ->put( String->new( value => 'orgGroupByCountry' ), ORG_CATALOG )
            ->put( String->new( value => 'orgGroupByTypeOfOrgName' ), ORG_CATALOG )
            ->put( String->new( value => 'part' ), PART_CATALOG )
        	#Many other put statements
    }

    sub get_grouping_type ( $self, $grouping ) {
        my $r = __PACKAGE__->_catalog_codes->get(
            String->new( value => $grouping ) );
        return $r if ( defined $r );
        confess 'Invalid grouping!';
    }

    #Other attributes and methods here.
    no MooseX::ClassAttribute;
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $r = ReportCatalogueIndexCommandParser->new();
is( $r->get_grouping_type('part'),
    ReportCatalogueIndexCommandParser->PART_CATALOG );
done_testing();
1;
