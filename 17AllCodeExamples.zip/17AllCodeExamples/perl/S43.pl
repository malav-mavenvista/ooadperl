use 5.026;
use warnings;
use utf8;

package Customer {
    use Moose;

    has 'home_address' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'work_address' => ( is => 'rw', isa => 'Str', default => q{} );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package IDeliveryAddress {
    use Moose::Role;
    requires 'to_string';

    no Moose::Role;
    1;
}

package HomeAddress {
    use Moose;
    with 'IDeliveryAddress';
    has 'customer' => ( is => 'ro', isa => 'Customer', required => 1 );

    sub to_string {
        my $self = shift;
        return $self->customer->home_address;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package WorkAddress {
    use Moose;
    with 'IDeliveryAddress';
    has 'customer' => ( is => 'ro', isa => 'Customer', required => 1 );

    sub to_string {
        my $self = shift;
        return $self->customer->work_address;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package SpecifiedAddress {
    use Moose;
    with 'IDeliveryAddress';
    has 'address_specified' => ( is => 'ro', isa => 'Str', required => 1 );

    sub to_string {
        my $self = shift;
        return $self->address_specified;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use Moose;

    has 'order_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_placing_order' =>
        ( is => 'ro', isa => 'Customer', required => 1 );
    has 'delivery_address' =>
        ( is => 'rw', isa => 'IDeliveryAddress', required => 1 );

    sub get_delivery_address {
        my $self = shift;
        return $self->delivery_address->to_string();
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $c = Customer->new( home_address => 'Mumbai', work_address => 'Ahmedabad' );
my $del_h = HomeAddress->new( customer => $c );
my $del_w = WorkAddress->new( customer => $c );
my $del_o = SpecifiedAddress->new( address_specified => 'India' );
my $o     = Order->new(
    order_id               => 'o1',
    customer_placing_order => $c,
    delivery_address       => $del_h
);

is( $o->get_delivery_address, 'Mumbai', 'Home address' );
$o->delivery_address($del_w);
is( $o->get_delivery_address, 'Ahmedabad', 'Work address' );
$o->delivery_address($del_o);
is( $o->get_delivery_address, 'India', 'Other address' );

done_testing();
1;
