use 5.026;
use warnings;
use utf8;

package UserType {
    use Moose;
    use MooseX::ClassAttribute;

    has 'password_max_age_in_days' =>
        ( is => 'ro', isa => 'Int', required => 1 );
    has 'can_print_report' => ( is => 'ro', isa => 'Bool', required => 1 );

    class_has 'NormalUserType' => (
        is      => 'ro',
        isa     => 'UserType',
        default => sub {
            UserType->new(
                password_max_age_in_days => 90,
                can_print_report         => 1
            );
        },
    );
    class_has 'AdminUserType' => (
        is      => 'ro',
        isa     => 'UserType',
        default => sub {
            UserType->new(
                password_max_age_in_days => 30,
                can_print_report         => 1
            );
        },
    );
    class_has 'GuestUserType' => (
        is      => 'ro',
        isa     => 'UserType',
        default => sub {
            UserType->new(
                password_max_age_in_days => 10_000,
                can_print_report         => 0
            );
        },
    );

    no MooseX::ClassAttribute;
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UserAccount {
    use Moose;
    use DateTime;

    has 'user_type' => ( is => 'ro', isa => 'UserType', required => 1 );
    has 'id'        => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'name'      => ( is => 'rw', isa => 'Str',      default  => q{} );
    has 'password'  => ( is => 'rw', isa => 'Str',      default  => q{} );
    has 'date_of_last_password_change' => (
        is      => 'rw',
        isa     => 'DateTime',
        default => sub { DateTime->today() },
    );

    sub check_password {
        my ( $self, $password ) = @_;

        #...
        return    #True if password correct.
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Inventory {
    use Moose;
    use DateTime;
    use Carp;

    sub login {
        my ( $self, $user_logging_in, $password ) = @_;
        if ( $user_logging_in->check_password($password) ) {
            if (DateTime->compare( DateTime->today(),
                    $self->get_account_expiry_date($user_logging_in) ) > 0
                )
            {
                #prompt user to change password here
            }
        }
        return $self;
    }

    sub get_account_expiry_date {
        my ( $self, $account ) = @_;
        my $password_max_age_in_days
            = $self->get_password_max_age_in_days($account);
        return $account->date_of_last_password_change->clone()
            ->add( days => $password_max_age_in_days );
    }

    sub get_password_max_age_in_days {
        my ( $self, $account ) = @_;
        return $account->user_type->password_max_age_in_days;
    }

    sub print_report {
        my ( $self, $current_user ) = @_;
        $current_user->user_type->can_print_report()
            || confess('You have no right');

        #print the report here
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $un = UserAccount->new( user_type => UserType->NormalUserType, id => 'v' );
my $app = Inventory->new();
is( $app->login( $un, q{} ), $app );
is( $app->print_report($un), $app );

done_testing();
1;
