use 5.026;
use warnings;
use utf8;

#improve the code
package FoodSalesReport {
	use Moose;
	use Try::Tiny;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'q0' => (is=>'rw', isa=>'Int', default=>0); #How many items of rice sold?
	has 'q1' => (is=>'rw', isa=>'Int', default=>0); #How many items of noodle sold?
	has 'q2' => (is=>'rw', isa=>'Int', default=>0); #How many items of drink sold?
	has 'q3' => (is=>'rw', isa=>'Int', default=>0); #How many items of dessert sold?

	sub load_data($self, $conn) {
		my $st = $conn->prepare_statement('select ' .
            'sum(case when foodType=0 then qty else 0 end) as totalQty0,'.
            'sum(case when foodType=1 then qty else 0 end) as totalQty1,'.
            'sum(case when foodType=2 then qty else 0 end) as totalQty2,'.
            'sum(case when foodType=3 then qty else 0 end) as totalQty3 '.
            'from foodSalesTable group by foodType');
		try {
			my $rs = $st->execute_query();
			try {
				$rs->next();
				$self->q0($rs->get_int('totalQty0'));
				$self->q1($rs->get_int('totalQty1'));
				$self->q2($rs->get_int('totalQty2'));
				$self->q3($rs->get_int('totalQty3'));
			} finally {
				$rs->close();
			}
		} finally {
			$st->close();
		}
    }

    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

#Dummy classes
package Connection {
	use Moose;
	sub prepare_statement {PreparedStatement->new()}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package PreparedStatement {
	use Moose;
	sub execute_query {ResultSet->new()}
	sub close {}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package ResultSet {
	use Moose;
	sub next {}
    sub get_int { 1 }
	sub close {}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
#End of Dummy classes
use Test::More;
my $f = FoodSalesReport->new();
$f->load_data(Connection->new());
is ($f->q0, 1);
done_testing();
1;