use 5.026;
use warnings;
use utf8;

# Suppose that in general, a teacher can teach many students. However, 
# a graduate student can be taught by a graduate teacher only. 
# Point out and remove the problem in the code:

package Student {
	use Moose;
	has 'student_id' => (is=>'ro', isa=>'Str', required=>1);
    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package Teacher {
	use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'teacher_id' => (is=>'ro', isa=>'Str', required=>1);
	has 'students_taught' => (is=>'ro', isa=>'ArrayRef[Student]', default=>sub{[]});

	sub add_student($self, $student) {
		push @{$self->students_taught}, $student;
	}
    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package GraduateStudent {
	use Moose;
	extends 'Student';
    #Some attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package GraduateTeacher {
	use Moose;
	extends 'Teacher';
    #Some attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More;
my $s = Student->new(student_id=>'s');
my $t = Teacher->new(teacher_id=>'t', students_taught=>[$s]);
my $gs = Student->new(student_id=>'gs');
my $gt = Teacher->new(teacher_id=>'gt', students_taught=>[$gs, $s]);

Teacher->new(teacher_id=>'t', students_taught=>[$gs]);#does not give error!!!!
done_testing();
1;