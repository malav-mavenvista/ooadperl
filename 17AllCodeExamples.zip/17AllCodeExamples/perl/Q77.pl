use 5.026;
use warnings;
use utf8;

package Employee {
	use Moose::Role;
	has 'id' => (is=>'ro', isa=>'Int', default=>0);
	has 'name' => (is=>'rw', isa=>'Str', default=>q{});
	has 'address' => (is=>'rw', isa=>'Str', default=>q{});
	has 'mobile' => (is=>'ro', isa=>'Str', default=>q{});
	requires 'calculate_holidays_permitted';
	#Some functions here.
	no Moose::Role;
	1;
}

package PermanentEmployee {
	use Moose;
	with 'Employee';
	use feature 'signatures';
	no warnings qw(experimental::signatures);
	sub calculate_holidays_permitted($self, $month) {
		return ($month == 12)?4:3;
	}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

package TemporaryEmployee {
	use Moose;
	with 'Employee';
	use feature 'signatures';
	no warnings qw(experimental::signatures);
	sub calculate_holidays_permitted($self, $month) {
		return 2;
	}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
use Test::More;
TemporaryEmployee->new()->calculate_holidays_permitted(1);
PermanentEmployee->new()->calculate_holidays_permitted(2);
done_testing();
1;