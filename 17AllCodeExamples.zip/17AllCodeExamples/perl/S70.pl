use 5.026;
use warnings;
use utf8;

package IGridListener {
    use Moose::Role;
    requires qw(on_row_appended on_row_moved);
    no Moose::Role;
    1;
}

package Grid {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'listeners' => (
        is      => 'ro',
        isa     => 'ArrayRef[IGridListener]',
        default => sub { [] },
    );

    sub scan_listeners ( $self, $process ) {
        foreach my $lr ( @{ $self->listeners } ) {
            $process->($lr);
        }
    }

    sub append_row($self) {
        #Append a row at the end of Grid
        $self->scan_listeners( sub { $_[0]->on_row_appended() } );
    }

    sub move_row ( $self, $existing_idx, $new_idx ) {
        #Move the row
        $self->scan_listeners(
            sub { $_[0]->on_row_moved( $existing_idx, $new_idx ) } );
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $g = Grid->new();
$g->append_row();
$g->move_row( 1, 2 );
done_testing();
1;

#We could have used an Interface and two classes implementing the interface.
#But each of the classes would then contain only one line of actual code.
#So here we use subroutine references.
#This example in other languages like Java uses Interfaces because
#Java doesn't support subroutine references like Perl.
