use 5.026;
use warnings;
use utf8;

# This is a word processor application. It can let the user select the
# font. Before the user confirms to change the font, it will let the
# user preview the effect of the change. The current code is shown below.
# Point out the code smell. If we need to reuse the ChooseFontDialog
# in a GUI application that doesn't support this preview functionality,
# how should you change the code?

package WordProcessorMainFrame {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub on_change_font($self) {
        my $choose_font_dialog = ChooseFontDialog->new( main_frame => $self );
        if ( $choose_font_dialog->show_on_screen() ) {
            my $new_font = $choose_font_dialog->selected_font();
            #Show contents, using $new_font
        }
        else {
            #Show contents with existing font
        }
    }

    sub preview_with_font ( $self, $font ) {
        #show the contents using the preview font
    }

    #Other methods and attributes here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ChooseFontDialog {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'main_frame' =>
        ( is => 'ro', isa => 'WordProcessorMainFrame', required => 1 );
    has 'selected_font' => ( is => 'rw', isa => 'Str', default => q{} );

    sub show_on_screen {
        1    #...
    }

    #Other methods and attributes here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
WordProcessorMainFrame->new()->on_change_font();
done_testing();
1;
