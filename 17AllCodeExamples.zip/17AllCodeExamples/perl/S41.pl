use 5.026;
use warnings;
use utf8;

package Session {
    use Moose;
    use DateTime;

    has 'date'       => ( is => 'ro', isa => 'DateTime', required => 1 );
    has 'start_hour' => ( is => 'ro', isa => 'Int',      required => 1 );
    has 'end_hour'   => ( is => 'ro', isa => 'Int',      required => 1 );

    sub get_duration {
        my $self = shift;
        return $self->end_hour - $self->start_hour;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Course {
    use Moose::Role;
    requires 'get_fee', 'get_duration';

    has 'course_title' => ( is => 'ro', isa => 'Str', required => 1 );

    no Moose::Role;
    1;
}

package SimpleCourse {
    use Moose;
    use List::Util qw(sum0);
    with 'Course';

    has 'sessions' =>
        ( is => 'ro', isa => 'ArrayRef[Session]', default => sub { [] } );
    has 'fee' => ( is => 'rw', isa => 'Num', default => 0 );

    sub get_fee {
        my $self = shift;
        return $self->fee;
    }

    sub get_duration {
        my $self = shift;
        return sum0 map { $_->get_duration() } @{ $self->sessions };
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CompoundCourse {
    use Moose;
    with 'Course';
    use List::Util qw(sum0);

    has 'modules' =>
        ( is => 'ro', isa => 'ArrayRef[Course]', default => sub { [] } );

    sub get_fee {
        my $self = shift;
        return sum0 map { $_->fee } @{ $self->modules };
    }

    sub get_duration {
        my $self = shift;
        return sum0 map { $_->get_duration() } @{ $self->modules };
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $s1 = Session->new( date => DateTime->today, start_hour => 9,
    end_hour => 10 );
my $s2 = Session->new( date => DateTime->today, start_hour => 18,
    end_hour => 20 );

my $html = SimpleCourse->new(
    course_title => 'html',
    fee          => 100,
    sessions     => [$s1]
);
is( $html->get_duration, 1,   'Html duration' );
is( $html->get_fee,      100, 'Html fee' );

my $css = SimpleCourse->new( course_title => 'css', fee => 75,
    sessions => [$s2] );
is( $css->get_duration, 2,  'Css duration' );
is( $css->get_fee,      75, 'Css fee' );

my $web = CompoundCourse->new( course_title => 'web',
    modules => [ $html, $css ] );
is( $web->get_duration, 3,   'Web duration' );
is( $web->get_fee,      175, 'Web fee' );

done_testing();
1;
