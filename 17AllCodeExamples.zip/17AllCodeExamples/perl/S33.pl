use 5.026;
use warnings;
use utf8;

package SurveyData {
    use Moose;
    use MooseX::ClassAttribute;

    has 'base_file_name' => ( is => 'ro', isa => 'Str',  required => 1 );
    has 'hide_data_file' => ( is => 'ro', isa => 'Bool', required => 1 );

    sub set_save_path {
    	my $self = shift;
        return 'c:/application/data/' . $self->base_file_name . '.dat';
    }

    class_has 'RawDataType' => (
        is      => 'ro',
        isa     => 'SurveyData',
        default => sub {
            SurveyData->new( base_file_name => 'raw', hide_data_file => 1 );
        },
    );
    class_has 'CleanedUpDataType' => (
        is      => 'ro',
        isa     => 'SurveyData',
        default => sub {
            SurveyData->new(
                base_file_name => 'cleanedUp',
                hide_data_file => 1
            );
        },
    );
    class_has 'ProcessedDataType' => (
        is      => 'ro',
        isa     => 'SurveyData',
        default => sub {
            SurveyData->new(
                base_file_name => 'processed',
                hide_data_file => 1
            );
        },
    );
    class_has 'PublicationDataType' => (
        is      => 'ro',
        isa     => 'SurveyData',
        default => sub {
            SurveyData->new(
                base_file_name => 'publication',
                hide_data_file => 0
            );
        },
    );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $s = SurveyData->RawDataType;
$s->set_save_path();
done_testing();
1;
