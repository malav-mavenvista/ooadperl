use 5.026;
use warnings;
use utf8;

package UIDialogShower {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub show ( $class, $dialog, $left, $top ) {
        $dialog->pack();
        $dialog->set_location( $left, $top );
        $dialog->set_visible(1);
    }

    use constant { LEFT_PIXEL => 400, TOP_PIXEL => 200 };

    sub show_at_default_position ( $class, $dialog ) {
        __PACKAGE__->show( $dialog, LEFT_PIXEL, TOP_PIXEL );
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ChangePasswordButton {
    use Moose;
    extends 'JButton';
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'enclosing_dialog' =>
        ( is => 'bare', isa => 'JDialog', required => 1 );

    sub BUILD ( $self, $args ) {
        my $action = sub {
            my $d = UIChangeAccountPW->new(
                enclosed_by => $args->{enclosing_dialog},
                title       => 'chg pw',
                visible     => 1
            );
            UIDialogShower->show_at_default_position($d);
        };
        $self->add_action_listener($action);
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIDialogCustomerMain {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'JDialog';

    has 'btn_order_del' => ( is => 'ro', isa => 'JButton' );
    has '_btn_cust_change_password' =>
        ( is => 'rw', isa => 'ChangePasswordButton' );

    sub BUILD ( $self, $args ) {
        $self->_btn_cust_change_password(
            ChangePasswordButton->new( enclosing_dialog => $self ) );
    }

    sub bind_events($self) {

        #...
        my $action = sub {
            my $d = UIDialogCustomerDeleteOrder->new( $self, 'Del Order', 1 );
            UIDialogShower->show_at_default_position($d);
        };
        $self->btn_order_del->add_action_listener($action);
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIDialogRestaurantMain {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'JDialog';

    has '_btn_change_password' => ( is => 'rw', isa => 'JButton' );

    sub BUILD ( $self, $args ) {
        $self->_btn_change_password(
            ChangePasswordButton->new( enclosing_dialog => $self ) );
    }

    sub bind_events($self) {
        #...
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#Some dummy classes for above code to compile/run
package JDialog {
    use Moose::Role;
    sub pack                { }
    sub set_location        { }
    sub set_visible         { }
    sub add_action_listener { }
    no Moose::Role;
    1;
}

package JButton {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIDialogCustomerDeleteOrder {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIChangeAccountPW {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#End of dummy classes

use Test::More;
my $button = JButton->new();
my $u      = UIDialogCustomerMain->new( btn_order_del => $button );
$u->bind_events();
$u = UIDialogRestaurantMain->new();
$u->bind_events();
done_testing();
1;
