use 5.026;
use warnings;
use utf8;

#improve the code
package FoodSalesReport {
	use Moose;
	use Try::Tiny;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'rice_sold' => (is=>'rw', isa=>'Int', default=>0);
	has 'noodle_sold' => (is=>'rw', isa=>'Int', default=>0);
	has 'drink_sold' => (is=>'rw', isa=>'Int', default=>0);
	has 'dessert_sold' => (is=>'rw', isa=>'Int', default=>0);

	use constant {
		RICE_CODE=>0,
		NOODLE_CODE=>1,
		DRINK_CODE=>2,
		DESSERT_CODE=>3,
     	SUM_CASE => 'sum(case when foodType=',
     	QTY_IF=>' then qty else 0 end)'
    };


	sub load_data($self, $conn) {
		my $sql_s = $conn->prepare_statement('select ' .
            SUM_CASE . RICE_CODE    . QTY_IF . q{,} .
            SUM_CASE . NOODLE_CODE  . QTY_IF . q{,} .
            SUM_CASE . DRINK_CODE   . QTY_IF . q{,} .
            SUM_CASE . DESSERT_CODE . QTY_IF .
            ' from foodSalesTable group by foodType');
		my $rs = undef;
		try {
			$rs = $sql_s->execute_query();
			$rs->next();
			$self->rice_sold($rs->get_int(1));
			$self->noodle_sold($rs->get_int(2));
			$self->drink_sold($rs->get_int(3));
			$self->dessert_sold($rs->get_int(4));
		} finally {
			$rs->close() if (defined $rs);
			$sql_s->close();
		}
	}

    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

#Dummy classes
package Connection {
	use Moose;
	sub prepare_statement {PreparedStatement->new()}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package PreparedStatement {
	use Moose;
	sub execute_query {ResultSet->new()}
    sub close {}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package ResultSet {
	use Moose;
	sub next {}
	sub get_int { 1 }
	sub close {}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
#End of Dummy classes
use Test::More;
my $f = FoodSalesReport->new();
$f->load_data(Connection->new());
is ($f->rice_sold, 1);
done_testing();
1;