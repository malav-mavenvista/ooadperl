use 5.026;
use warnings;
use utf8;

# Suppose that in general, a teacher can teach many students. However, 
# a graduate student can be taught by a graduate teacher only. 
# Point out and remove the problem in the code:

package Student {
	use Moose::Role;
	has 'student_id' => (is=>'ro', isa=>'Str', required=>1);
	no Moose::Role;
	1;
}
package NonGraduateStudent {
	use Moose;
	with 'Student';
    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package GraduateStudent {
	use Moose;
	with 'Student';
    #Other attributes and methods here.	
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package Teacher {
	use Moose::Role;
	has 'teacher_id' => (is=>'ro', isa=>'Str', required=>1);
	no Moose::Role;
	1;
}
package NonGraduateTeacher {
	use Moose;
	with 'Teacher';
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'students_taught' => (is=>'ro', isa=>'ArrayRef[NonGraduateStudent]', default=>sub{[]});

	sub add_student($self, $student) {
		push @{$self->students_taught}, $student;
	}
    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package GraduateTeacher {
	use Moose;
	with 'Teacher';
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'students_taught' => (is=>'ro', isa=>'ArrayRef[Student]', default=>sub{[]});

	sub add_student($self, $student) {
		push @{$self->students_taught}, $student;
	}
    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
use Test::More;
my $s = NonGraduateStudent->new(student_id=>'s');
my $t = NonGraduateTeacher->new(teacher_id=>'t', students_taught=>[$s]);
my $gs = GraduateStudent->new(student_id=>'gs');
my $gt = GraduateTeacher->new(teacher_id=>'gt', students_taught=>[$s, $gs]);

#will give error if next line uncommented.
#NonGraduateTeacher->new(teacher_id=>'t', students_taught=>[$gs]);
done_testing();
1;

#This technique is primarily useful in statically typed languages,
#because the function signature in add_student can be of type 
#NonGraduateStudent or GraduateStudent.
#In perl, Moose makes parameter checks only in constructor.
#So after object is constructed, a NonGraduateTeacher can teach GraduateStudent here