use 5.026;
use warnings;
use utf8;

#Suppose you are writing a module to approve personal loans and
#before doing that you want to validate the personal information.
#Later on, its required to approve vehicle loans, consumer goods loans and what not.
package LoanApprovalHandler {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub approve_personal_loan ( $self, $validator ) {
        if ( $validator->is_valid() ) {
            #Process the loan
        }
    }

    sub approve_vehicle_loan ( $self, $validator ) {
        if ( $validator->is_valid() ) {
            #Process the loan
        }
    }

    #Methods for approving other loans
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package PersonalLoanValidator {
    use Moose;

    sub is_valid {
        #Validation logic
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package VehicleLoanValidator {
    use Moose;

    sub is_valid {
        #Validation logic
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
LoanApprovalHandler->new->approve_personal_loan(
    PersonalLoanValidator->new() );
LoanApprovalHandler->new->approve_personal_loan(
    VehicleLoanValidator->new() );
done_testing();
1;
