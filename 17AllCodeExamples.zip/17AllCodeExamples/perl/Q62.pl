use 5.026;
use warnings;
use utf8;
use feature 'signatures';
no warnings qw(experimental::signatures);

# A CSV file book.csv contains lots of information in format
# ISBN,Title,Price
# 123,Java,500
# 234,C#,700
# 345,OOAD,600
#
# Our goal is to find sum all the book prices.
# Also report number of valid and invalid books.
# The procedural code is given below.

my $current_book_price = 0;
my $total_price        = 0;
my $valid_records      = 0;
my $invalid_records    = 0;
open my $csv_fh, '<', 'books.csv' or die "Failed to open in input mode: $!";
my $line = <$csv_fh>;    #skip the header line

sub validate_price($line) {
    $current_book_price = 0;
    my ( $isbn, $title, $price ) = split /,/, $line;
    return unless defined $isbn and defined $title and defined $price;
    if ( length($isbn) < 2 || length($title) < 2 ) {return}
    return unless ( $price =~ /^[0-9]+$/ );
    $current_book_price = int $price;
}

while ( $line = <$csv_fh> ) {
    validate_price($line);
    if   ( $current_book_price > 0 ) { $valid_records++ }
    else                             { $invalid_records++ }
    $total_price += $current_book_price;
}
close $csv_fh;
printf "Total price of all books %g\n", $total_price;
printf "Total valid records %d\n",      $valid_records;
printf "Total invalid records %d\n",    $invalid_records;
1;

#Convert to reusable OO code
