use 5.026;
use warnings;
use utf8;

package Order {
    use Moose;
    use Math::BigInt;
    use HashMap;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'order_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'rest_to_receive_order'  => ( is => 'rw', isa => 'Restaurant' );
    has 'customer_placing_order' => ( is => 'rw', isa => 'Customer' );
    has 'shipping_address' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'order_items' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );

    sub get_total_amt($self) {
        my $total_amt = Math::BigInt->bzero();
        foreach my $product ( $self->order_items->keys_copy ) {
            my $price = $self->order_items->get($product);
            $total_amt->badd( Math::BigInt->new($price) );
        }
        return $total_amt;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
use String;
my $o = Order->new( order_id => 'a' );
$o->order_items->put( String->new( value => 'mobile1' ), 10 );
is( $o->get_total_amt->numify(), 10 );
done_testing();
1;
