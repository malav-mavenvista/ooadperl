use 5.026;
use warnings;
use utf8;

#In statically typed languages (like Java), we prefer to pass/return Optional, 
#instead of null/undef, from functions.
#The function signature makes it clear that the parameter/return value is Optional.
#Perl is dynamically typed i.e. functions don't use 'type' for 
#parameter and return values. So replacing undef with Optional object, doesn't lead to improvent in design, 
#in most cases, in perl.
#
#Solution for this exercise is present only in statically typed language 
#like Java/C#/C++.
