use 5.026;
use warnings;
use utf8;

package MainApp {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'progress_bar' => (
        is      => 'rw',
        isa     => 'ProgressBar',
        default => sub { ProgressBar->new() }
    );

    sub main($self) {
        my $fc = FileCopier->new(
            copy_monitor => sub { $self->update_progress_bar(@_) } );
        $fc->copy_file( 'f1.doc', 'f2.doc' );
    }

    sub update_progress_bar ( $self, $no_bytes_copies, $size_of_source ) {
        $self->progress_bar->percentage(
            $no_bytes_copies * 100 / $size_of_source );
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package FileCopier {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'copy_monitor' =>
        ( is => 'ro', isa => 'CodeRef', default => sub { } );

    sub copy_file ( $self, $source, $target ) {
        my $size_of_source = 0;    #Set file size
        for ( my $i = 0; $i < $size_of_source; ) {
            my $n = 512;
            #read n (<= 512) bytes from source.
            #write n bytes to target.
            $i += $n;
            $self->copy_monitor->( $i, $size_of_source );
        }
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ProgressBar {
    use Moose;
    has 'percentage' => ( is => 'rw', isa => 'Num', default => 0 );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
MainApp->new()->main();
done_testing();
1;

#We could have used an interface, but for demo purposes we have use a subroutine
#reference here
# In the above case, suppose that you need to develop another text mode
# file copying application that will display a "*" for each 10% of
# progress in its text console. What should you do?
