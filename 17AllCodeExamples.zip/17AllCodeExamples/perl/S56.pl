use 5.026;
use warnings;
use utf8;

package Restaurant {
    use Moose;
    has 'name'     => ( is => 'rw', isa => 'Str', required => 1 );
    has 'password' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'tel_no'   => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'fax_no'   => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'address'  => ( is => 'rw', isa => 'Str', default  => q{} );

    #some methods here
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}

package RestaurantTaskActivator {
    use Moose::Role;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    requires 'do_something_to_restaurant';

    has 'verification_code' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'restaurant' => ( is => 'ro', isa => 'Restaurant', required => 1 );

    sub try_to_activate ( $self, $rest_name, $verification_code ) {
        if (   $rest_name eq $self->restaurant->name
            && $self->verification_code eq $verification_code )
        {
            $self->do_something_to_restaurant();
            return 1;
        }
        return 0;
    }
    no Moose::Role;
    1;
}

package RestaurantActivator {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'RestaurantTaskActivator';
    sub do_something_to_restaurant($self) {
        #add restaurant to system.
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package FaxNoActivator {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'RestaurantTaskActivator';
    has 'new_fax_no' => ( is => 'ro', isa => 'Str', required => 1 );
    sub do_something_to_restaurant($self) {
        $self->restaurant->fax_no( $self->new_fax_no );
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package RestaurantTaskActivators {
    use Moose;
    use List::MoreUtils qw(firstidx);
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'activators' => (
        is      => 'ro',
        isa     => 'ArrayRef[RestaurantTaskActivator]',
        default => sub { [] }
    );

    sub activate ( $self, $rest_name, $verification_code ) {
        my $idx
            = firstidx { $_->try_to_activate( $rest_name, $verification_code ) }
        @{ $self->activators };
        return $self if ( $idx < 0 );
        splice @{ $self->activators }, $idx, 1;
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Category {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'cat_id' => ( is => 'rw', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Holidays {
    use Moose;
    use DateTime;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'holidays' =>
        ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );
    sub add_holiday ( $self, $year, $month, $day ) {
        #...
    }
    sub remove_holiday ( $self, $year, $month, $day ) {
        #...
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BusinessSessions {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'business_sessions' =>
        ( is => 'ro', isa => 'ArrayRef[Object]', default => sub { [] } );
    sub add_buiness_session ( $self, $from_hour, $from_min, $to_hour, $to_min ) {
        #...
    }
    sub is_in_business_hour ( $self, $time ) {
        #...
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package RestaurantSystem {
    use Moose;
    use HashMap;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'restaurants' =>
        ( is => 'ro', isa => 'ArrayRef[Restaurant]', default => sub { [] } );
    has 'restaurantTaskActivators' => (
        is      => 'ro',
        isa     => 'RestaurantTaskActivators',
        default => sub { RestaurantTaskActivators->new() }
    );
    has 'map_rest_id_to_categories' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );
    has 'map_rest_id_to_holidays' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );
    has 'map_rest_id_to_business_sessions' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $r = Restaurant->new( name => 'abc' );
my $ra
    = RestaurantActivator->new( restaurant => $r, verification_code => 'vi' );
$ra->try_to_activate( 'abc', 'vi' );
my $fa = FaxNoActivator->new(
    restaurant        => $r,
    verification_code => 'vi',
    new_fax_no        => '12'
);
$fa->try_to_activate( 'abc', 'vi' );
my $all_ac = RestaurantTaskActivators->new( activators => [ $ra, $fa ] );
$all_ac->activate( 'abc', 'vi' );
Category->new( cat_id => 'abc' );
Holidays->new();
BusinessSessions->new();
RestaurantSystem->new();
done_testing();
1;
