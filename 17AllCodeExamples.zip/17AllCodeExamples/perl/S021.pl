use 5.026;
use warnings;
use utf8;

package BookRental {
    use Moose;

    has 'id'            => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_name' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BookRentals {
    use Moose;
    use Try::Tiny;
    use Carp;
    use List::MoreUtils qw(firstidx);

    has 'rentals' =>
        ( is => 'ro', isa => 'ArrayRef[BookRental]', default => sub { [] } );

    sub _get_rental_idx_by_id {
        my ( $self, $rental_id ) = @_;
        my $rental_idx = firstidx { $rental_id eq $_->id } @{ $self->rentals };
        confess 'Rental not found' if ( $rental_idx < 0 );
        return $rental_idx;
    }

    sub get_customer_name {
        my ( $self, $rental_id ) = @_;
        return $self->rentals->[ $self->_get_rental_idx_by_id($rental_id) ]
            ->customer_name;
    }

    sub delete_rental {
        my ( $self, $rental_id ) = @_;
        splice @{ $self->rentals }, $self->_get_rental_idx_by_id($rental_id),
            1;
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b1 = BookRental->new( id => 'b1', customer_name => 'vi' );
my $b2 = BookRental->new( id => 'b2', customer_name => 'jay' );
my $rentals = BookRentals->new( rentals => [ $b1, $b2 ] );
is( $rentals->get_customer_name('b1'), 'vi' );
is( $rentals->delete_rental('b2'),     $rentals );
done_testing();
1;
