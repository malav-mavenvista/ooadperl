use 5.026;
use warnings;
use utf8;

package Account {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    #check if the password is complex enough, i.e.,
    #contains letter and digit/symbol.
    sub is_complex_password ( $self, $password ) {
        my $dg_sym_found = 0;    #found a digit or symbol?
        my $letter_found = 0;
        for my $i ( 0 .. length($password) - 1 ) {
            my $c = substr( $password, $i, 1 );
            if ( ( $c =~ /\p{Uppercase}/ ) || ( $c =~ /\p{Lowercase}/ ) ) {
                $letter_found = 1;
            }
            else {
                $dg_sym_found = 1;
            }
        }
        return $dg_sym_found && $letter_found;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $a = Account->new();
ok( $a->is_complex_password('A1') );
done_testing();
1;
