use 5.026;
use warnings;
use utf8;

package Interface1 {
	use Moose::Role;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	requires 'func1';
	with 'RolesOfInterface', 'OrAbstractClass';



	no Moose::Role;
	1;
}

package Class1 {
	use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	has 'x' => (is=>'ro', isa=>'Int', required=>1);

    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More;
#main program
done_testing();
1;