use 5.026;
use warnings;
use utf8;

package Account {
    use Moose::Role;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    requires 'calc_interest';

    has 'balance' => ( is => 'ro', isa => 'Num', default => 0 );

    sub get_interest_rate($self) {
        1    #...some method
    }

    #Other attributes and methods here.
    no Moose::Role;
    1;
}

package SavingsAccount {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'Account';

    sub calc_interest($self) {
        return $self->balance * $self->get_interest_rate();
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ChequeAccount {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'Account';

    sub calc_interest($self) {
        return 0;
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package FixedAccount {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'Account';

    sub calc_interest($self) {
        return $self->balance * ( $self->get_interest_rate() + 0.02 );
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
my $a = ChequeAccount->new();
is( $a->calc_interest,                      0 );
is( SavingsAccount->new()->calc_interest(), 0 );
is( FixedAccount->new()->calc_interest(),   0 );
done_testing();
1;
