use 5.026;
use warnings;
use utf8;

package BookRental {
    use Moose;

    has 'id'            => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_name' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BookRentals {
    use Moose;
    use Try::Tiny;
    use Carp;
    has 'rentals' =>
        ( is => 'ro', isa => 'ArrayRef[BookRental]', default => sub { [] } );

    sub _get_position {
    	my ($self, $rental_id) = @_;
    	my $position = 0;
        foreach my $rental ( @{ $self->rentals } ) {
            return $position if ( $rental_id eq $rental->id );
            $position++;
        }
        confess 'Rental not found';
    }

    sub get_customer_name {
        my ( $self, $rental_id ) = @_;
        return $self->rentals->[$self->_get_position($rental_id)]->customer_name;
    }

    sub delete_rental {
        my ( $self, $rental_id ) = @_;
        my $position = $self->_get_position($rental_id);
        splice @{ $self->rentals }, $position, 1;
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $b1 = BookRental->new( id => 'b1', customer_name => 'vi' );
my $b2 = BookRental->new( id => 'b2', customer_name => 'jay' );
my $rentals = BookRentals->new( rentals => [ $b1, $b2 ] );
is( $rentals->get_customer_name('b1'), 'vi' );
is( $rentals->delete_rental('b2'),     $rentals );
done_testing();
1;
