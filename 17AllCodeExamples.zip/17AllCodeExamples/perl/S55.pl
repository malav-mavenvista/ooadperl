use 5.026;
use warnings;
use utf8;

package IReport {
    use Moose::Role;
    requires 'print';
    no Moose::Role;
    1;
}
package Report1 {
    use Moose;
    with 'IReport';
    sub to_string {'r1'}
    sub print {
        #print some fancy report
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Report2 {
    use Moose;
    with 'IReport';
    sub to_string {'r2'}
    sub print {
        #print some fancy report
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
#...
package Report31c {
    use Moose;
    with 'IReport';
    sub to_string {'r31c'}
    sub print {
        #print some fancy report
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Form1 {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'combo_box_report_type' => ( is => 'rw', isa => 'JComboBox' );
    has 'reports'               => ( is => 'rw', isa => 'ArrayRef[IReport]' );

    sub BUILD ( $self, $args ) {
        $self->combo_box_report_type( JComboBox->new() );
        $self->reports(
            [   Report1->new(), Report2->new(),    #...
                Report31c->new()
            ]
        );
        foreach my $r ( @{ $self->reports } ) {
            $self->combo_box_report_type->add_item($r);
        }
    }
    sub on_print_click($self) {
        $self->combo_box_report_type->get_selected_item()->print();
    }
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package JComboBox {    #dummy class
    use Moose;
    sub add_item          { }
    sub get_selected_item { Report2->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
Form1->new()->on_print_click();
done_testing();
1;
