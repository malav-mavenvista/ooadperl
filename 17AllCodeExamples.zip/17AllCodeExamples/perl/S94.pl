use 5.026;
use warnings;
use utf8;

package Course {
	use Moose;
	has 'course_id' => (is=>'rw', isa=>'Str', default=>q{});
	has 'title' => (is=>'rw', isa=>'Str', default=>q{});
	has 'fee' => (is=>'rw', isa=>'Int', default=>0);
	has 'sessions' => (is=>'ro', isa=>'ArrayRef[Session]', default=>sub{[]});
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package  Session {
	use Moose;
	use DateTime;
	has 'date' => (is=>'rw', isa=>'DateTime');
	has 'start_hour' => (is=>'rw', isa=>'Int', default=>0);
	has 'end_hour' => (is=>'rw', isa=>'Int', default=>0);
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

package ICourses {
	use Moose::Role;
	requires qw(add_course delete_course update_course 
				get_all_courses_by_id get_courses_longer_than);
	no Moose::Role;
	1;
}
package CoursesInDB {
	use Moose;
	use Try::Tiny;
	with 'ICourses';
	use feature 'signatures';
	no warnings qw(experimental::signatures);
    has 'db_conn' => (
        is      => 'ro',
        isa     => 'DbConnection',
        default => sub { DbConnection->new() }
    );

	sub add_course($self, $course) {
		my $st = $self->db_conn->prepare_statement(
			'insert into from Courses values (?, ?, ?)');
		try {
			$st->set_string(1, $course->course_id);
			$st->set_string(2, $course->title);
			$st->set_int(3, $course->fee);
			$st->execute_update();
		} finally {
			$st->close();
		};
		$st = $self->db_conn->prepare_statement(
			'insert into from Sessions values (?, ?, ?, ?,?)');
		try {
			my $i = 0;
			foreach my $session (@{$course->sessions}) {
				$st->set_string(1, $course->course_id);
				$st->set_string(2, $i++);
				$st->set_date(3, $session->date);
				$st->set_int(4, $session->start_hour);
				$st->set_int(5, $session->end_hour);
			}
		} finally {
			$st->close();
		};
	}
	sub get_courses_longer_than ($self, $duration) {
		#....		
	}
	sub delete_course {}
	sub update_course {}
	sub get_all_courses_by_id{}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

#Some dummy classes
package DbConnection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string    { }
    sub set_int    { }
    sub set_date {}
    sub execute_update { ResultSet->new() }
    sub close         { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $s = Session->new();
my $c = Course->new(sessions=>[$s]);
CoursesInDB->new()->add_course($c);
done_testing();
1;