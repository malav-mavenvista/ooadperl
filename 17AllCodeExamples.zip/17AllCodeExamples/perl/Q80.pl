use 5.026;
use warnings;
use utf8;

#This is a small program handling zip files. The user can input the
# path to the zip file such as c:\f.zip and the paths to the files
# that he would like to add to the zip file such as c:\f1.doc,
# c:\f2.doc and etc. in the main frame, then the program will compress
# f1.doc and f2.doc and create f.zip. When it is compressing each file,
# the status bar in the main frame will display the related message.
# For example, when it is compressing c:\f2.doc,
# the status bar will display "zipping c:\f2.zip".

package ZipMainFrame {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'status_bar' => (
        is      => 'rw',
        isa     => 'StatusBar',
        default => sub { StatusBar->new() }
    );

    sub make_zip($self) {
        my ( $zip_file_path, $src_file_paths ) = ( q{}, [] );
        #setup zipFilePath and srcFilePaths according to the UI.
        #...
        my $ze = ZipEngine->new();
        $ze->make_zip( $zip_file_path, $src_file_paths, $self );
    }

    sub set_status_bar ( $self, $status_text ) {
        $self->status_bar->text($status_text);
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ZipEngine {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub make_zip ( $self, $zip_file_path, $src_file_paths, $zip_ui ) {
        #create zip file at the path
        #...
        foreach my $f ( @{$src_file_paths} ) {
            $zip_ui->set_status_bar("Zipping $f");
            #add the file $f to the zip file.
        }
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package StatusBar {
    use Moose;
    has 'text' => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
ZipMainFrame->new()->make_zip();
done_testing();
1;
