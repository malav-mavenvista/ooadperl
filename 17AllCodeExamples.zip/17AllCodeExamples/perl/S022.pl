use 5.026;
use warnings;
use utf8;

package TelNo {
    use Moose;

    has 'tel_country_code' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'tel_area_code'    => ( is => 'rw', isa => 'Str', default => q{} );
    has 'tel_local_number' => ( is => 'rw', isa => 'Str', default => q{} );

    #some methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package PersonName {
    use Moose;

    has 'first_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'last_name'  => ( is => 'rw', isa => 'Str', default => q{} );

    #some methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ContactPerson {
    use Moose;

    has 'english_name' => ( is => 'rw', isa => 'PersonName' );
    has 'chinese_name' => ( is => 'rw', isa => 'PersonName' );
    has 'tel_no'       => ( is => 'rw', isa => 'TelNo' );
    has 'fax_no'       => ( is => 'rw', isa => 'TelNo' );
    has 'mobile_no'    => ( is => 'rw', isa => 'TelNo' );

    #some methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Organization {
    use Moose;

    has 'id'           => ( is => 'ro', isa => 'Str', required => 1 );
    has 'english_name' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'chinese_name' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'tel_no'       => ( is => 'rw', isa => 'TelNo' );
    has 'fax_no'       => ( is => 'rw', isa => 'TelNo' );
    has 'contact_person' => ( is => 'rw', isa => 'ContactPerson' );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $p = Organization->new( id => 'Company' );
ok( defined $p, 'Organization object created' );
done_testing();
1;