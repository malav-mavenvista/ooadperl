use 5.026;
use warnings;
use utf8;

package IRentalProcessor {
    use Moose::Role;
    requires 'process';
    no Moose::Role;
    1;
}

package PrintRentals {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IRentalProcessor';

    sub process ( $self, $rental ) {
        print $rental;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CountRentals {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IRentalProcessor';
    has 'count' => ( is => 'rw', isa => 'Int', default => 0 );

    sub process ( $self, $rental ) {
        $self->count( $self->count + 1 );
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BookRentals {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'rentals' =>
        ( is => 'ro', isa => 'ArrayRef[BookRental]', default => sub { [] } );

    sub count_rentals($self) { scalar @{ $self->rentals } }
    sub get_rental_at ( $self, $position ) { $self->rentals->[$position] }

    sub is_overdue ( $self, $rental ) {
        return $rental->is_overdue()    # and some complex condition here
    }

    sub process_overdue_rentals ( $self, $rental_processor ) {
        map { $rental_processor->process($_) } 
        	grep { $self->is_overdue($_) }  @{ $self->rentals };
    }

    sub print_overdue_rentals($self) {
        $self->process_overdue_rentals( PrintRentals->new() );
    }

    sub count_overdue_rentals($self) {
        my $count_processor = CountRentals->new();
        $self->process_overdue_rentals($count_processor);
        return $count_processor->count;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#dummy classes for running script
package BookRental {
    use Moose;
    sub is_overdue {1}
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b = BookRentals->new( rentals => [ BookRental->new() ] );
$b->print_overdue_rentals();
$b->count_overdue_rentals();
done_testing();
1;

#Here the interface IRentalProcessor and two class: PrintRentals & CountRentals,
#seem to be an over design. 
#If the class has only one line (like in this case), we can pass
#subroutine references to method instead. So IRentalProcessor, PrintRentals and 
#CountRentals can be removed for simplicity.
#The interface solution is shown here for demo purposes.
