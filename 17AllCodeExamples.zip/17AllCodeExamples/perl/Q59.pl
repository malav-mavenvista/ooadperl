use 5.026;
use warnings;
use utf8;
package DiscountInfo {
	use Moose;
	has 'supplier_id' => (is=>'ro', isa=>'Str', required=>1);
	has 'customer' => (is=>'ro', isa=>'Customer', required=>1);
	has 'product' => (is=>'ro', isa=>'Str', required=>1);
	has 'discount' => (is=>'ro', isa=>'Num', required=>1);
    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}
package OrderLine {
	use Moose;
	has 'product' => (is=>'rw', isa=>'Str');
	has 'quantity' => (is=>'rw', isa=>'Int');
	has 'price' => (is=>'rw', isa=>'Num', default=>0);
    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}
package Order {
	use Moose;
	use DateTime;
	has 'id' => (is=>'rw', isa=>'Str');
	has 'date_of_order' => (is=>'rw', isa=>'DateTime');
	has 'customer_id' => (is=>'rw', isa=>'Str');
	has 'supplier_id' => (is=>'rw', isa=>'Str');
	has 'line_items' => (is=>'ro', isa=>'ArrayRef[OrderLine]', default=>sub{[]});
    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}
package Customer {
	use Moose;
	has 'id' => (is=>'rw', isa=>'Str');
	has 'name' => (is=>'rw', isa=>'Str');
	has 'address' => (is=>'rw', isa=>'Str');
    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}
package Supplier {
	use Moose;
	has 'id' => (is=>'rw', isa=>'Str');
	has 'name' => (is=>'rw', isa=>'Str');
	has 'tel_no' => (is=>'rw', isa=>'Str');
	has 'address' => (is=>'rw', isa=>'Str');
    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}
package SalesSystem {
	use Moose;
	has 'customers' => (is=>'ro', isa=>'ArrayRef[Customer]', default=>sub{[]});
	has 'suppliers' => (is=>'ro', isa=>'ArrayRef[Supplier]', default=>sub{[]});
	has 'orders' => (is=>'ro', isa=>'ArrayRef[Order]', default=>sub{[]});
	has 'discounts' => (is=>'ro', isa=>'ArrayRef[DiscountInfo]', default=>sub{[]});


    no Moose;
	__PACKAGE__->meta->make_immutable;
	1;
}

use Test::More;
Customer->new();
Supplier->new();
SalesSystem->new();
done_testing();
1;

# Implement the following new requirements while keeping the code fit:
#
# 1. Customers can place orders. Each order has a unique ID. It records the
# date of the order, the ID of the customer and the name and quantity of
# each item being ordered.
# 2. The system can list all the orders placed by a particular customer.
# 3. The system can list all the orders placed for a particular supplier.
# 4. A supplier can provide a certain discount to some of the customers it
# selects (valid for some selected items only). The discount for different
# customers or different items may be different. 
