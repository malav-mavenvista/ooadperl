use 5.026;
use warnings;
use utf8;

package IGridListener {
    use Moose::Role;
    requires qw(on_row_appended on_row_moved);
    no Moose::Role;
    1;
}

#For this exercise, try to eliminate the duplication of foreach statement.
package Grid {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'listeners' => (
        is      => 'ro',
        isa     => 'ArrayRef[IGridListener]',
        default => sub { [] }
    );

    sub append_row($self) {
        #Append a row at the end of Grid
        $_->on_row_appended() foreach @{ $self->listeners };
    }

    sub move_row ( $self, $existing_idx, $new_idx ) {
        #Move the row
        $_->on_row_moved( $existing_idx, $new_idx )
            foreach @{ $self->listeners };
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $g = Grid->new();
$g->append_row();
$g->move_row( 1, 2 );
done_testing();
1;
