use 5.026;
use warnings;
use utf8;

# This application is concerned with the training courses.
# The schedule of a course can be expressed in three ways (as of now):
#   weekly, range or list.
# A weekly schedule is like "every Tuesday for 5 weeks starting
#   from Oct. 22".
# A range schedule is like "Every day from Oct. 22 to Nov. 3".
# A list schedule is like "Oct. 22, Oct. 25, Nov. 3, Nov. 10".
# In this exercise we will ignore the time and just assume that it is
# always 7:00pm-10:00pm. It is expected that new ways to express the
# schedule may be added in the future.
# Point out and remove the code smells in the code

package Course {
    use Moose;
    use DateTime;

    has 'schedule_type' => (
        traits   => ['Enumeration'],
        is       => 'ro',
        required => 1,
        enum     => [qw/weekly range list/],
        handles  => 1,
    );
    has 'course_title' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'no_weeks'  => ( is => 'rw', isa => 'Int', default => 0 ); #For weekly
    has 'from_date' => ( is => 'rw', isa => 'DateTime' ); #For weekly and range
    has 'to_date' => ( is => 'rw', isa => 'DateTime' ); #For range
    has 'date_list' => ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );#For list

    sub get_duration_in_days {
        my $self = shift;
        return $self->no_weeks if ( $self->is_weekly() );
        return scalar @{ $self->date_list } if ( $self->is_list() );
        return $self->to_date()->delta_days( $self->from_date() )->in_units('days') if ( $self->is_range() );
        return 0;    #Unknown schedule type!
    }

    sub print_schedule {
        my $self = shift;
        if ( $self->is_weekly ) {
            #...
        }
        if ( $self->is_range ) {
            #...
        }
        if ( $self->is_list ) {
            #...
        }
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $w = Course->new(
    schedule_type => 'weekly',
    course_title  => 'UML',
    no_weeks      => 2,
    from_date     => DateTime->today()
);
is( $w->get_duration_in_days, 2 );

my $r = Course->new(
    schedule_type => 'range',
    course_title  => 'OOAD',
    from_date     => DateTime->today(),
    to_date       => DateTime->today()->add( days => 7 )
);
is( $r->get_duration_in_days, 7 );

my @days = map { DateTime->today()->add( days => $_ ) } ( 0 .. 3 );
my $l    = Course->new(
    schedule_type => 'list',
    course_title  => 'Perl',
    date_list     => \@days
);
is( $l->get_duration_in_days, 4 );

done_testing();
1;
