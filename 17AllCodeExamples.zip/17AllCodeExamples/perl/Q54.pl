use 5.026;
use warnings;
use utf8;

package Account {
    use Moose;
    use DateTime;
    use constant {
        LEVEL_USER  => 1,
        LEVEL_ADMIN => 2,
    };
    has 'account_level' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'expired_date'  => ( is => 'rw', isa => 'DateTime' );#for user account only
    has 'has_login' => ( is => 'rw', isa => 'Bool', default => 0 ); #for admin account only

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ERPApp {
    use Moose;
    use DateTime;

    sub check_login_issue {
        my ( $self, $account ) = @_;
        if ( $account->account_level == Account->LEVEL_USER ) {
            #Check the account expired DateTime
            my $now = DateTime->today();
            return 0 if ( DateTime->compare( $now, $account->expired_date ) < 0 );
            return 1;
        }
        if ( $account->account_level == Account->LEVEL_ADMIN ) {
            #No expired date for admin account
            #Check multi-login
            return 0 if ( $account->has_login );
            return 1;
        }
        return 0;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $a = Account->new(
    account_level => Account->LEVEL_USER,
    expired_date  => DateTime->today()
);
my $app = ERPApp->new();
ok( $app->check_login_issue($a) );
$a = Account->new( account_level => Account->LEVEL_ADMIN );
ok( $app->check_login_issue($a) );
done_testing();
1;
