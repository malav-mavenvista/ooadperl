use 5.026;
use warnings;
use utf8;

package Badge {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'participant_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'participant_english_full_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'participant_chi_full_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'eng_org_name'    => ( is => 'rw', isa => 'Str', default => q{} );
    has 'chi_org_name'    => ( is => 'rw', isa => 'Str', default => q{} );
    has 'eng_org_country' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'chi_org_country' => ( is => 'rw', isa => 'Str', default => q{} );

    sub BUILD ( $self, $args ) {
        $self->load_info_from_db();
    }

    sub load_info_from_db($self) {
        $self->get_participant_full_names();
        $self->get_org_name_and_country();
    }

    sub get_participant_full_names($self) {
        my $parts_in_db = ParticipantsInDB->new();
        my $part = $parts_in_db->locate_participant( $self->participant_id );
        if ( defined $part ) {
            $self->participant_english_full_name(
                "$part->e_last_name, $part->e_first_name");
            $self->participant_chi_full_name(
                $part->c_last_name . $part->c_first_name );
        }
    }

    sub get_org_name_and_country($self) {
        my $orgs_in_db = OrganizationsInDB->new();
        my $oid        = $orgs_in_db->find_organization_employing(
            $self->participant_id );
        if ( defined $oid ) {
            my $org = $orgs_in_db->locate_organization($oid);
            $self->eng_org_name( $org->e_name );
            $self->chi_org_name( $org->c_name );
            $self->eng_org_country( $org->e_address->country );
            $self->chi_org_country( $org->c_address->country );
        }
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

#dummy classes to run above code
package ParticipantsInDB {
    use Moose;
    sub locate_participant { Participant->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package OrganizationsInDB {
    use Moose;
    sub find_organization_employing {'org'}
    sub locate_organization         { Organization->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Participant {
    use Moose;
    has 'e_last_name'  => ( is => 'rw', isa => 'Str', default => q{} );
    has 'e_first_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_last_name'  => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_first_name' => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Address {
    use Moose;
    has 'country' => ( is => 'rw', isa => 'Str', default => q{} );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Organization {
    use Moose;
    has 'e_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'c_name' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'e_address' =>
        ( is => 'rw', isa => 'Address', default => sub { Address->new() } );
    has 'c_address' =>
        ( is => 'rw', isa => 'Address', default => sub { Address->new() } );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
#end of dummy classes

use Test::More;
Badge->new( participant_id => '1' );
done_testing();
1;
