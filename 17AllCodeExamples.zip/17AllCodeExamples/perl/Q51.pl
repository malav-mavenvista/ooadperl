use 5.026;
use warnings;
use utf8;

package Department {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant { ACCOUNT => 0, MARKETING => 1, CUSTOMER_SERVICE => 2 };
    has 'department_code' => ( is => 'ro', isa => 'Int', required => 1 );

    sub get_department_name($self) {
        return 'Account' if $self->department_code == __PACKAGE__->ACCOUNT;
        return 'Marketing'
            if $self->department_code == __PACKAGE__->MARKETING;
        return 'Customer Services'
            if $self->department_code == __PACKAGE__->CUSTOMER_SERVICE;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
is( Department->new( department_code => Department->MARKETING )->get_department_name(),
    'Marketing' );
done_testing();
1;
