use 5.026;
use warnings;
use utf8;

#Keep things that vary separate from things that are constant.
package IResource {
    use Moose::Role;
    requires 'get_free', 'mark_free';
    no Moose::Role;
    1;
}

package File1 {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IResource';
    sub get_free($self) { }
    sub mark_free ( $self, $resource_id ) { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Database1 {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IResource';
    sub get_free($self) { }
    sub mark_free ( $self, $resource_id ) { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ResourceTracker {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    use constant {
        RESOURCE_TYPE_FILE1     => 1,
        RESOURCE_TYPE_DATABASE1 => 2,
    };
    sub allocate ( $self, $resource ) {
        return $resource->get_free();
    }
    sub free ( $self, $resource, $resource_id ) {
        $resource->mark_free($resource_id);
        return $self;
    }
    sub mark_database_free { }
    sub mark_file_free     { }
    sub get_free_file      { }
    sub get_free_database  { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $f  = File1->new();
my $d  = Database1->new();
my $ra = ResourceTracker->new();
$ra->allocate($f);
$ra->free( $f, 1 );
$ra->allocate($d);
$ra->free( $d, 1 );
done_testing();
1;
