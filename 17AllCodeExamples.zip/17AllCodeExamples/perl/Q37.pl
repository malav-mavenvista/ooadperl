use 5.026;
use warnings;
use utf8;

package Payment {
    use Moose;
    use DateTime;
    use Try::Tiny;
    use Carp;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant {
        FOC         => 'FOC',           #Free of charge
        TT          => 'TT',            #paid by telegraphic transfer
        CHEQUE      => 'Cheque',        #paid by cheque
        CREDIT_CARD => 'CreditCard',    #paid by credit CreditCard
        CASH        => 'Cash',          #paid by cash
    };

    #Type of payment must be one of above constants
    has 'payment_type' => ( is => 'ro', isa => 'Str', required => 1 );

    has 'payment_date' => ( is => 'rw', isa => 'DateTime' );
    	#if FOC, the date the fee is waived
    has 'actual_payment' => ( is => 'rw', isa => 'Int', default => 0 );
    	#if FOC, then it is always 0
    has 'discount' => ( is => 'rw', isa => 'Int', default => 0 );
        #if FOC, the amount that is waived
    has 'bank_name' => ( is => 'rw', isa => 'Str', default => q{} );
      	#if it is by TT, Cheque or Credit card
    has 'cheque_number' => ( is => 'rw', isa => 'Str', default => q{} );
    	#if it is by Cheque

    #if it is by credit card
    has 'credit_card_type' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_holder_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_number' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_expiry_date' => ( is => 'rw', isa => 'DateTime' );

    sub get_nominal_payment($self) {
    	return $self->actual_payment;
    }

    sub get_bank_name($self) {
        return $self->bank_name if (   $self->payment_type eq TT
            						or $self->payment_type eq CHEQUE
            						or $self->payment_type eq CREDIT_CARD );
        confess 'bank name is undefined for this payment type';
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b = Payment->new( payment_type => Payment->CHEQUE );
$b->get_nominal_payment();
$b->get_bank_name();
done_testing();
1;
