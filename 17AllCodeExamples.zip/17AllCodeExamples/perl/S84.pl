use 5.026;
use warnings;
use utf8;

package IFontChangeListener {
    use Moose::Role;
    requires 'on_font_changed';
    no Moose::Role;
    1;
}

package WordProcessorMainFrame {
    use Moose;
    with 'IFontChangeListener';
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub on_change_font($self) {
        my $choose_font_dialog
            = ChooseFontDialog->new( font_change_listener => $self );
        if ( $choose_font_dialog->show_on_screen() ) {
            my $new_font = $choose_font_dialog->selected_font();
            #Show contents, using $new_font
        }
        else {
            #Show contents with existing font
        }
    }

    sub on_font_changed ( $self, $new_font ) {
        $self->preview_with_font($new_font);
    }

    sub preview_with_font ( $self, $font ) {
        #show the contents using the preview font
    }
    #Other methods and attributes here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ChooseFontDialog {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'font_change_listener' =>
        ( is => 'ro', isa => 'IFontChangeListener', required => 1 );
    has 'selected_font' => ( is => 'rw', isa => 'Str', default => q{} );
    sub show_on_screen {
        1    #...
    }
    #Other methods and attributes here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
WordProcessorMainFrame->new()->on_change_font();
done_testing();
1;
