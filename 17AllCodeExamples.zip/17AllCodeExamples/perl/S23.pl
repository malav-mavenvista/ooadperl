use 5.026;
use warnings;
use utf8;

#Improve the code
package TokenStream {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'parsed_token_list' =>
        ( is => 'rw', isa => 'ArrayRef[Str]', default => sub { [] } );
    has 'current_token_idx_in_list' =>
        ( is => 'rw', isa => 'Int', default => 0 );
    has 'char_input_source_for_parsing' =>
        ( is => 'ro', isa => 'BufferedReader', required => 1 );
    has 'previous_char_read_from_source' =>
        ( is => 'rw', isa => 'Int', default => 0 );

    sub BUILD ( $self, $args ) {
        $self->take_char();
        $self->parsed_token_list( $self->parse_tokens_from_input_source() );
    }

    sub take_char($self) {
        #....
    }

    sub parse_tokens_from_input_source($self) {
        my $tokens_passed_so_far = [];
        #...
        return $tokens_passed_so_far;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package BufferedReader {
    use Moose;
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
TokenStream->new( char_input_source_for_parsing => BufferedReader->new() );
done_testing();
1;
