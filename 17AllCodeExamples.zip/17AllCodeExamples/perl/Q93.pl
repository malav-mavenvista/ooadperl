use 5.026;
use warnings;
use utf8;

# This is a web-based application concerned with training courses.
# A user can choose a subject area
# 		("IT", "Management", "Language", "Apparel")
# in a form and click submit. Then the application will display all
# the courses in that subject area. The code doing that is shown below.

package ShowCoursesServlet {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub do_get ( $self, $request, $response ) {
        $response->content_type('text/html');
        my $out = $response->writer();
        $out->println('<HTML><TITLE>Course listing</TITLE><BODY>');
        my $db_conn = DbConnection->new();
        my $st      = $db_conn->prepare_statement(
            'select * from courses where subjArea=?');
        try {
            $st->set_string( 1, $request->get_parameter('subjArea') );
            my $rs = $st->execute_query();
            try {
                $out->println('<Table>');
                while ( $rs->next ) {
                    $out->println('<TR>');
                    $out->println('<TD>');
                    $out->println( $rs->get_string(1) );    #course code
                    $out->println('</TD>');
                    $out->println('<TD>');
                    $out->println( $rs->get_string(2) );    #course name
                    $out->println('</TD>');
                    $out->println('<TD>');
                    $out->println( $rs->get_int(3) );       #course fee in MOP
                    $out->println('</TD>');
                    $out->println('</TR>');
                }
            }
            finally {
                $rs->close();
            };
        }
        finally {
            $st->close();
        };
        $out->println('</body></html>');
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Request {
    use Moose;
    sub get_parameter { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Response {
    use Moose;
    has 'content_type' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'writer'       => (
        is      => 'rw',
        isa     => 'PrintWriter',
        default => sub { PrintWriter->new() }
    );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PrintWriter {
    use Moose;
    sub println { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package DbConnection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string    { }
    sub execute_query { ResultSet->new() }
    sub close         { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package ResultSet {
    use Moose;
    sub next       {0}
    sub get_string {' '}
    sub get_int    {0}
    sub close      { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
ShowCoursesServlet->new()->do_get( Request->new(), Response->new() );
done_testing();
1;
#Your tasks are:
# 1. Point out and remove the problems in the code.
# 2. Divide your revised code into appropriate layers.