use 5.026;
use warnings;
use utf8;

#EmployeeList does not want to inherit the addNode method.
#Employee is not a Node.

package Node {
    use Moose;

    has 'next_node' => ( is => 'ro', isa => 'Node' );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package LinkList {
    use Moose;
    use MooseX::StrictConstructor;

    has 'first_node' => (
        is       => 'rw',
        isa      => 'Node',
        init_arg => undef,
        writer   => '_set_first_node',
    );

    sub add_node {
        my ( $self, $node ) = @_;
        #Add a new node in linked List
        return $self;
    }

    no MooseX::StrictConstructor;
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Employee {
    use Moose;

    has 'employee_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'name'        => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package EmployeeNode {
    use Moose;
    extends 'Node';

    has 'employee' => ( is => 'ro', isa => 'Employee', required => 1 );

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package EmployeeList {
    use Moose;
    has '_list' =>
        ( is => 'ro', isa => 'LinkList', default => sub { LinkList->new() } );

    sub add_employee {
        my ( $self, $employee ) = @_;
        my $n = EmployeeNode->new( employee => $employee );
        $self->_list->add_node($n);
        return $self;
    }

    sub get_first_employee {
        my $self = shift;
        return $self->_list->first_node->employee;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $n = Node->new();
my $l = LinkList->new();
is( $l->add_node($n), $l );

my $e  = Employee->new( employee_id => 1, name => 'v' );
my $el = EmployeeList->new();
is( $el->add_employee($e), $el );

done_testing();
1;
