use 5.026;
use warnings;
use utf8;

package IAccount {
    use Moose::Role;
    #Some attributes and methods
    no Moose::Role;
    1;
}

package Restaurant {
    use Moose;
    use DateTime;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IAccount';

    #the string 'Rest' is concated with the restaurant ID to form the key.
    use constant RESTAURANT_ID_TEXT => 'Rest';

    has 'website' => ( is => 'rw', isa => 'Str', default => q{} );

    has 'addr_cn' => ( is => 'rw', isa => 'Str', default => q{} ); #address in Chinese
    has 'addr_en' => ( is => 'rw', isa => 'Str', default => q{} ); #address in English

    #the restaurant would like to update its fax no with this. After it is
    #confirmed, it will be stored in Account. Before that, it is stored
    #here.
    has 'numb_newfax' => ( is => 'rw', isa => 'Str',  default => q{} );
    has 'has_newfax'  => ( is => 'rw', isa => 'Bool', default => 0 );

    #list of holidays
    has 'holiday' => ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );

    #id of the category this restaurant belongs to.
    has 'cat_id' => ( is => 'rw', isa => 'Str', default => q{} );

    #a list of business session. Each business session is an array
    #of two times. The first time is the start time. The second time
    #is the end time. The restaurant is open for business in each
    #session.
    has 'bs_hour' => ( is => 'ro', isa => 'ArrayRef[Object]', default => sub { [] } );

    #y: year.
    #m: month.
    #d: date.
    sub add_holiday ( $self, $y, $m, $d ) {
        $y += 1900 if ( $y < 1900 );
        my $dt = DateTime->new( year => $y, month => $m, day => $d );
        push @{ $self->holiday }, $dt;
    }

    sub add_bs_hour ( $self, $from_hr, $from_min, $to_hr, $to_min ) {
        my $f_min = $from_hr * 60 + $from_min;    #start time in minutes
        my $t_min = $to_hr * 60 + $to_min;        #end time iin minutes
             #make sure both times are valid and the start time is earlier
             #than the end time.
        if (   $f_min >= 0
            && $f_min <= 1440
            && $t_min >= 0
            && $t_min <= 1440
            && $f_min < $t_min )
        {
            push @{ $self->bs_hour }, [ $f_min, $t_min ];
            return 1;
        }
        return 0;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $r = Restaurant->new();
$r->add_holiday( 2019, 1, 1 );
$r->add_bs_hour( 10, 0, 18, 0 );
is ($r->bs_hour->[0]->[0], 600);
done_testing();
1;
