use 5.026;
use warnings;
use utf8;

package IValidator {
    use Moose::Role;
    requires 'is_valid';
    no Moose::Role;
    1;
}

package PersonalLoanValidator {
    use Moose;
    with 'IValidator';

    sub is_valid {
        #Validation logic
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package VehicleLoanValidator {
    use Moose;
    with 'IValidator';

    sub is_valid {
        #Validation logic
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package LoanApprovalHandler {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub approve_loan ( $self, $validator ) {
        if ( $validator->is_valid() ) {
            #Process the loan
        }
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
LoanApprovalHandler->new->approve_loan( PersonalLoanValidator->new() );
LoanApprovalHandler->new->approve_loan( VehicleLoanValidator->new() );
done_testing();
1;
