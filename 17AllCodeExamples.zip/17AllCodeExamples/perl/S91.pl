use 5.026;
use warnings;
use utf8;

package Order {
	use Moose;
	has 'order_id' => (is=>'rw', isa=>'Str');
	has 'customer_id' => (is=>'rw', isa=>'Str');
	has 'rest_id' => (is=>'rw', isa=>'Str');
	has 'items' => (is=>'rw', isa=>'ArrayRef[OrderItem]');
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package OrderItem {
	use Moose;
	has 'food_id' => (is=>'rw', isa=>'Str');
	has 'quantity' => (is=>'rw', isa=>'Int');
	has 'unit_price' => (is=>'rw', isa=>'Num');
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package IOrders {
	use Moose::Role;
	requires qw(add_order delete_order update_order get_orders_by_id);
	no Moose::Role;
	1;
}
package OrdersInDB {
	use Moose;
	use Try::Tiny;
	with 'IOrders';
	use feature 'signatures';
	no warnings qw(experimental::signatures);
    has 'db_conn' => (
        is      => 'ro',
        isa     => 'DbConnection',
        default => sub { DbConnection->new() }
    );

	sub add_order($self, $order) {
		my $st = $self->db_conn->prepare_statement(
			'insert into from Orders values(?,?,?)');
		try {
			$st->set_string(1, $order->order_id);
			$st->set_string(2, $order->customer_id);
			$st->set_string(3, $order->rest_id);
			$st->execute_update();
		} finally {
			$st->close();
		};

		$st = $self->db_conn->prepare_statement(
			'insert into from OrderItems values (?,?,?,?,?)');
		try {
			my $i=0;
			foreach my $order_item (@{$order->items}) {
				$st->set_string(1, $order->order_id);
				$st->set_int(2, $i++);
				$st->set_string(3, $order_item->food_id);
				$st->set_int(4, $order_item->quantity);
				$st->set_double(5, $order_item->unit_price);
				$st->execute_update();
			}
		}finally {
			$st->close();
		};
	}
	sub delete_order {}
	sub update_order {}
	sub get_orders_by_id {}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
#Some empty classes to run above code
package DbConnection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string    { }
    sub set_int    { }
    sub set_double    { }
    sub execute_update { ResultSet->new() }
    sub close         { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
my $o = Order->new(items=>[OrderItem->new()]);
OrdersInDB->new()->add_order($o);
done_testing();
1;

