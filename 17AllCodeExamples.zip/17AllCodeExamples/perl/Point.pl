use 5.026;
use warnings;
use utf8;

package Point1 {
	use Moose;
	has 'x' => (is=>'ro', isa=>'Int', required=>1);
	has 'y' => (is=>'ro', isa=>'Int', required=>1);
	sub move() {
		my ($self, $dx, $dy) = @_;
		return Point1->new($self->x + $dx, $self->y + $dy);
	}

    #Some methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package Point2 {
	use Moose;
	has 'x' => (is=>'rw', isa=>'Int', required=>1);
	has 'y' => (is=>'rw', isa=>'Int', required=>1);
	sub move() {
		my ($self, $dx, $dy) = @_;
		$self->x($self->x + $dx);
		$self->y($self->y + $dy);
		return $self;
	}
    #Some methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}


use Test::More;
#main program
done_testing();
1;