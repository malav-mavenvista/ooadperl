use 5.026;
use warnings;
use utf8;

# This application lets the network administrators document their
# server configurations.
# Originally we had a simple Server class as shown in the code:
package Administrator {
    use Moose;
    with 'IEquals';
    has 'name' => (is=>'ro', isa=>'Str', required=>1);
    sub equals {
        my ($self, $other) = @_;
        return $self->name eq $other->name;
    }
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package DHCPServer {
    use Moose;
    has 'start_ip' => (is=>'ro', isa=>'Str', required=>1);
    has 'end_ip' => (is=>'ro', isa=>'Str', required=>1);
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package FileServer {
    use Moose;
    has 'quota' => (is=>'ro', isa=>'HashRef[Int]', default=>sub{{}});
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Server {
    use Moose;
    with 'IEquals';
    has 'name'            => ( is => 'ro', isa => 'Str', required => 1 );
    has 'cpu_model'       => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'ram_size_in_GB'  => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'disk_size_in_GB' => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'ip_address'      => ( is => 'rw', isa => 'Str', default  => q{} );
    sub equals {
        my ($self, $other) = @_;
        return $self->name eq $other->name;
    }
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ServerConfigSystem {
    use Moose;
    use HashMap;
    has '_servers' =>
        ( is => 'ro', isa => 'ArrayRef[Server]', default => sub { [] } );
    has 'server_care_taker' => (is=>'ro', isa=>'HashMap', default=>sub {HashMap->new()});
    has 'dhcp_servers' => (is=>'ro', isa=>'HashMap', default=>sub{HashMap->new()});
    has 'file_servers' => (is=>'ro', isa=>'HashMap', default=>sub{HashMap->new()});

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#Now, there are four new requirements. You are required to implement
#these requirements without modifying the Server class:
# 1. An administrator (identified by an admin ID) can be assigned
#    to be responsible for a server.
# 2. We can check if a server is a DHCP server or not. If yes,
#    we can record the address scope it manages
#    (e.g., from 192.168.0.21 to 192.168.0.254).
# 3. We can check if a server is a file server or not. If yes, we can
#    set and check the disk space quota allocated for each user
#    (identified by a user ID).
# 4. A server can be a DHCP server and a file server at the same time.

use Test::More;
my $s1 = Server->new( name => 's1' );
my $a1 = Administrator->new(name => 'a1');
my $a2 = Administrator->new(name => 'a1');
my $sys1 = ServerConfigSystem->new();
$sys1->server_care_taker->put($a2, $s1);
print $sys1->server_care_taker->get($a1)->name();
done_testing();
1;
