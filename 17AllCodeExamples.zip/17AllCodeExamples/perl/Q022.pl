use 5.026;
use warnings;
use utf8;

package TelephoneNumber {
    use Moose;
    has 'country_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'area_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'local_number' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}
package Name {
    use Moose;
    as 'first_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'last_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}
package ContactPerson {
    use Moose;
    has 'english_name' => 
        ( is => 'rw', isa => 'Name', default => q{} );
    has 'chinese_name' => 
        ( is => 'rw', isa => 'Name', default => q{} );
        ;

    has 'tel_no' => ( is => 'rw', isa => 'TelephoneNumber' );
    has 'fax_no' => ( is => 'rw', isa => 'TelephoneNumber' );
    has 'mobile_no' => ( is => 'rw', isa => 'TelephoneNumber' );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}
package LanguageEquivalent {
    use Moose;
    as 'english_value' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'chinese_value' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;

}
package Organization {
    use Moose;

    has 'id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'name' => ( is => 'rw', isa => 'LanguageEquivalent' );
    has 'tel_no' => ( is => 'rw', isa => 'TelephoneNumber' );
    has 'fax_no' => ( is => 'rw', isa => 'TelephoneNumber' );
    has 'contact_person' = (is=>'rw', isa=>'ContactPerson');
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $p = Organization->new( id => 'Company' );
ok( defined $p, 'Organization object created' );
done_testing();
1;