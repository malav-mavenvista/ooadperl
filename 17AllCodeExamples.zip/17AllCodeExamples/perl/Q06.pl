use 5.026;
use warnings;
use utf8;

package ReportCatalogueIndexCommandParser {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant {
        NO_GROUPING  => 'orgNoGrouping',
        ORG_CATALOG  => 0,
        PART_CATALOG => 1,
        #....  other codes
    };

    sub get_grouping_type ( $self, $grouping ) {
        return ORG_CATALOG  if ( $grouping eq NO_GROUPING );
        return ORG_CATALOG  if ( $grouping eq 'orgGroupByCountry' );
        return ORG_CATALOG  if ( $grouping eq 'orgGroupByTypeOfOrgName' );
        return PART_CATALOG if ( $grouping eq 'part' );
        #... Many more similar statements
        confess 'Invalid grouping!';
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $r = ReportCatalogueIndexCommandParser->new();
is( $r->get_grouping_type('part'),
    ReportCatalogueIndexCommandParser->PART_CATALOG );
done_testing();
1;
