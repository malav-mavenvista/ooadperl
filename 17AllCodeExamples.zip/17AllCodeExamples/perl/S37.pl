use 5.026;
use warnings;
use utf8;

package Payment {
    use Moose::Role;
    use DateTime;
    requires 'get_nominal_payment';
    has 'payment_date' => ( is => 'rw', isa => 'DateTime' );
    no Moose::Role;
    1;
}

package FreeOfCharge {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'Payment';
    has 'amount_waived' => ( is => 'rw', isa => 'Int', default => 0 );

    sub get_nominal_payment($self) {
        return $self->amount_waived;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package RealPayment {
    use Moose::Role;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'Payment';
    has 'actual_payment' => ( is => 'rw', isa => 'Int', default => 0 );
    has 'discount'       => ( is => 'rw', isa => 'Int', default => 0 );

    sub get_nominal_payment($self) {
        return $self->actual_payment + $self->discount;
    }
    no Moose::Role;
    1;
}

package CashPayment {
    use Moose;
    with 'RealPayment';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BankPayment {
    use Moose::Role;
    with 'RealPayment';
    has 'bank_name' => ( is => 'rw', isa => 'Str', default => q{} );
    no Moose::Role;
    1;
}

package TelegraphicTransfer {
    use Moose;
    with 'BankPayment';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ChequePayment {
    use Moose;
    with 'BankPayment';
    has 'cheque_number' => ( is => 'rw', isa => 'Str', default => q{} );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CreditCardPayment {
    use Moose;
    with 'BankPayment';
    has 'credit_card_type' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_holder_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_number' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'credit_card_expiry_date' => ( is => 'rw', isa => 'DateTime' );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
CreditCardPayment->new();
ChequePayment->new( cheque_number => '123' );
TelegraphicTransfer->new();
CashPayment->new();
FreeOfCharge->new( amount_waived => 1, payment_date => DateTime->today() );
done_testing();
1;
