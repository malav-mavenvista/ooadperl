use 5.026;
use warnings;
use utf8;

#Database logic
package OrdersInDB {
    use Moose;
    use Try::Tiny;
    use Carp;
    with 'IOrders';
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'db_conn' => (
        is      => 'ro',
        isa     => 'DbConnection',
        default => sub { DbConnection->new() }
    );

    sub get_order ( $self, $order_id ) {
        my $st = $self->db_conn->prepare_statement(
            'select * from orders where orderId=?');
        try {
            $st->set_string( 1, $order_id );
            my $rs = $st->execute_query();
            try {
                if ( !$rs->next() ) { confess('Error: Order not found') }
                my $customer_id = $rs->get_string('customerId');
                my $customers   = CustomersInDB->new();
                my $customer    = $customers->get_customer($customer_id);
                my $order       = Order->new( customer => $customer );
                #Initialize other parameters of $order
                $self->get_order_items_from_DB($order);
                return $order;
            }
            finally {
                $rs->close();
            }
        }
        finally {
            $st->close();
        };

    }

    sub get_order_items_from_DB ( $self, $order ) {
        my $st = $self->db_conn->prepare_statement(
            'select * from OrderItems where orderId=?');
        try {
            $st->set_string( 1, $order->id );
            my $rs = $st->execute_query();
            try {
                while ( $rs->next() ) {
                    $order->add_order_item(
                        OrderItem->new(
                            food_id  => $rs->get_string(3),
                            quantity => $rs->get_int(4)
                        )
                    );
                }
            }
            finally {
                $rs->close();
            }
        }
        finally {
            $st->close();
        };
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package CustomersInDB {
    use Moose;
    use Try::Tiny;
    use Carp;
    with 'ICustomers';
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'db_conn' => (
        is      => 'ro',
        isa     => 'DbConnection',
        default => sub { DbConnection->new() }
    );

    sub get_customer ( $self, $customer_id ) {
        my $st = $self->db_conn->prepare_statement(
            'select * from Customers where customerId=?');
        try {
            $st->set_string( 1, $customer_id );
            my $rs = $st->execute_query();
            try {
                if ( !$rs->next() ) { confess('Error: Customer not found') }
                return Customer->new( name => $rs->get_string('name') );
            }
            finally {
                $rs->close();
            }
        }
        finally {
            $st->close();
        };
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

#UI logic
package ShowOrderServlet {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub do_get ( $self, $request, $response ) {
        $response->content_type('text/html');
        my $out    = $response->writer();
        my $orders = OrdersInDB->new();
        $out->println('<html><title>Order details</title><body>');
        my $order_id = $request->get_parameter('orderId');
        my $order    = Order->new();
        try {
            $order = $orders->get_order($order_id);
        }
        catch {
            $out->println($_);
            return;
        }
        $out->println( 'Customer: ' . $order->customer->name );
        $self->show_order_items( $out, $order );
        $out->println('</body></html>');
    }

    sub show_order_items ( $self, $out, $order ) {
        $out->println('<Table>');
        foreach my $or ( @{ $order->order_items } ) {
            $out->println('<tr>');
            $out->println('<td>');
            $out->println( $or->food_id );
            $out->println('</td>');
            $out->println('<td>');
            $out->println( $or->quantity );
            $out->println('</td>');
            $out->println('</td>');
            $out->println('</tr>');
        }
        $out->println('</Table>');
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package IOrders {
    use Moose::Role;
    requires 'get_order';
    no Moose::Role;
    1;
}

package ICustomers {
    use Moose::Role;
    requires 'get_customer';
    no Moose::Role;
    1;
}

#dummy classes to run above code
package Order {
    use Moose;
    has 'id' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'customer' =>
        ( is => 'rw', isa => 'Customer', default => sub { Customer->new() } );
    has 'order_items' =>
        ( is => 'ro', isa => 'ArrayRef[OrderItem]', default => sub { [] } );
    sub add_order_item { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package OrderItem {
    use Moose;
    has 'food_id'  => ( is => 'rw', isa => 'Str', default => q{} );
    has 'quantity' => ( is => 'rw', isa => 'Int', default => 0 );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Customer {
    use Moose;
    has 'name' => ( is => 'rw', isa => 'Str', default => q{} );
    sub get_parameter { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Request {
    use Moose;
    sub get_parameter { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Response {
    use Moose;
    has 'content_type' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'writer'       => (
        is      => 'rw',
        isa     => 'PrintWriter',
        default => sub { PrintWriter->new() }
    );

    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PrintWriter {
    use Moose;
    sub println { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package DbConnection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string    { }
    sub execute_query { ResultSet->new() }
    sub close         { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package ResultSet {
    use Moose;
    sub next       {0}
    sub get_string {' '}
    sub get_int    {0}
    sub close      { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
#end of dummy classes

use Test::More;
done_testing();
1;
