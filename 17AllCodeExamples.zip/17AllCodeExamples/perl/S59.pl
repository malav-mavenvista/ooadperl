use 5.026;
use warnings;
use utf8;

package Order {
    use Moose;
    use DateTime;
    has 'order_id'    => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_id' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'supplier_id' => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'order_date' =>
        ( is => 'rw', isa => 'DateTime', default => sub { DateTime->today } );
    has 'line_items' =>
        ( is => 'ro', isa => 'ArrayRef[OrderLine]', default => sub { [] } );

    #some methods here
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package OrderLine {
    use Moose;
    has 'product_name' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'quanity'      => ( is => 'rw', isa => 'Int', default  => 0 );

    #some methods here
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Orders {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'orders' =>
        ( is => 'ro', isa => 'ArrayRef[Order]', default => sub { [] } );

    sub place_order ( $self, $customer_id, $supplier_id, @other ) {
        #...
    }

    sub print_orders_by_customer ( $self, $customer_id ) {
        #...
    }

    sub print_orders_for_supplier ( $self, $supplier_id ) {
        #...
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Discount {
    use Moose;
    has 'supplier_id'   => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_id'   => ( is => 'ro', isa => 'Str', required => 1 );
    has 'product_name'  => ( is => 'ro', isa => 'Str', required => 1 );
    has 'discount_rate' => ( is => 'rw', isa => 'Num', default  => 0 );

    #some methods here
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Discounts {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'discounts' =>
        ( is => 'ro', isa => 'ArrayRef[Discount]', default => sub { [] } );

    sub add_discount ( $self, $supplier_id, $customer_id, $product_name,
        $discount_rate )
    {
        #...
    }

    sub find_discount ( $self, $supplier_id, $customer_id, $product_name ) {
        #...
    }

    #some methods here
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Customer {
    use Moose;
    has 'id'      => ( is => 'rw', isa => 'Str' );
    has 'name'    => ( is => 'rw', isa => 'Str' );
    has 'address' => ( is => 'rw', isa => 'Str' );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Supplier {
    use Moose;
    has 'id'      => ( is => 'rw', isa => 'Str' );
    has 'name'    => ( is => 'rw', isa => 'Str' );
    has 'tel_no'  => ( is => 'rw', isa => 'Str' );
    has 'address' => ( is => 'rw', isa => 'Str' );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package SalesSystem {
    use Moose;
    has 'customers' =>
        ( is => 'ro', isa => 'ArrayRef[Customer]', default => sub { [] } );
    has 'suppliers' =>
        ( is => 'ro', isa => 'ArrayRef[Supplier]', default => sub { [] } );
    has 'orders'    => ( is => 'rw', isa => 'Orders',    required => 1 );
    has 'discounts' => ( is => 'rw', isa => 'Discounts', required => 1 );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $c = Customer->new();
my $s = Supplier->new();
Order->new( order_id => 'abc' );
OrderLine->new( product_name => 'p' );
my $o = Orders->new();
$o->place_order( $c->id, $s->id, () );
$o->print_orders_by_customer( $c->id );
$o->print_orders_for_supplier( $s->id );
Discount->new( supplier_id => 's', customer_id => 'c', product_name => 'p' );
my $d = Discounts->new();
SalesSystem->new( orders => $o, discounts => $d );
done_testing();
1;
