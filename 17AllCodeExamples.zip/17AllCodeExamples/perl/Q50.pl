use 5.026;
use warnings;
use utf8;

package Account {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant { SAVING => 0, CHEQUE => 1, FIXED => 2 };
    has 'account_type' => ( is => 'ro', isa => 'Int', required => 1 );

    has 'balance' => ( is => 'ro', isa => 'Num', default => 0 );

    sub get_interest_rate($self) {
        1 #...some method
    }

    sub calc_interest($self) {
        return $self->balance * $self->get_interest_rate()
            if $self->account_type == __PACKAGE__->SAVING;
        return 0 if $self->account_type == __PACKAGE__->CHEQUE;
        return $self->balance * ( $self->get_interest_rate() + 0.02 )
            if $self->account_type == __PACKAGE__->FIXED;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $a = Account->new(account_type=>Account->CHEQUE);
is($a->calc_interest, 0);
done_testing();
1;
