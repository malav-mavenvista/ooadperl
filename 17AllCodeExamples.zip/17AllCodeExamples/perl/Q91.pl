use 5.026;
use warnings;
use utf8;

 # This application is about restaurants. An order has an order ID,
 # a restaurant ID and a customer ID and contains some order items.
 # Each order item contains the food ID, the quantity and unit price.
 # You have created the tables and classes below.
 #       create table Orders (
 #       orderId varchar(20) primary key,
 #       customerId varchar(20) not null,
 #       restId varchar(20) not null
 #       );
 #       create table OrderItems (
 #       orderId varchar(20),
 #       itemId int,
 #       foodId varchar(20) not null,
 #       quantity int not null,
 #       unitPrice float not null,
 #       primary key(orderId, itemId)
 #       );

package Order {
	use Moose;
	has 'order_id' => (is=>'rw', isa=>'Str');
	has 'customer_id' => (is=>'rw', isa=>'Str');
	has 'rest_id' => (is=>'rw', isa=>'Str');
	has 'items' => (is=>'rw', isa=>'ArrayRef[OrderItem]');
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
package OrderItem {
	use Moose;
	has 'food_id' => (is=>'rw', isa=>'Str');
	has 'quantity' => (is=>'rw', isa=>'Int');
	has 'unit_price' => (is=>'rw', isa=>'Num');
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More;
OrderItem->new();
Order->new();
done_testing();
1;

#Your tasks are:
#1. Create an interface for accessing the orders, while hiding the database.
#2. Create a class to implement that interface and show how to implement
#   its method for adding an order to the database.