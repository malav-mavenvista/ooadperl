use 5.026;
use warnings;
use utf8;

package IAccount {
    use Moose::Role;
    #Some attributes and methods
    no Moose::Role;
    1;
}

package TimeRange {
    use Moose;
    has 'from_hour'    => ( is => 'ro', isa => 'Int', required => 1 );
    has 'to_hour'      => ( is => 'ro', isa => 'Int', required => 1 );
    has 'from_minutes' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'to_minutes'   => ( is => 'ro', isa => 'Int', required => 1 );

    #Some methods may be here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Restaurant {
    use Moose;
    use DateTime;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IAccount';

    use constant RESTAURANT_ID_TEXT => 'Rest';
    has 'website'         => ( is => 'rw', isa => 'Str', default => q{} );
    has 'chinese_address' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'english_address' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'new_fax_number_to_be_confirmed' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'has_new_fax' => ( is => 'rw', isa => 'Bool', default => 0 );
    has 'list_of_holidays' =>
        ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );
    has 'category_id' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'business_hours' =>
        ( is => 'ro', isa => 'ArrayRef[TimeRange]', default => sub { [] } );

    use constant { 
        BASE_YEAR => 1900,
        HOURS_IN_A_DAY => 24,
        MINUTES_IN_A_HOUR => 60
    };

    sub add_holiday ( $self, $year, $month, $day ) {
        $year += BASE_YEAR if ( $year < BASE_YEAR );
        push @{ $self->list_of_holidays },
            DateTime->new( year => $year, month => $month, day => $day );
        return $self;
    }

    sub get_minutes_from_midnight ( $self, $hours, $minutes ) {
        return $hours * MINUTES_IN_A_HOUR + $minutes;
    }

    sub is_minutes_within_one_day ( $self, $minutes ) {
        return ( $minutes >= 0 )
            && ( $minutes <= HOURS_IN_A_DAY * MINUTES_IN_A_HOUR );
    }

    sub add_bs_hour ( $self, $from_hour, $from_minute, $to_hour, $to_minute )
    {
        my $from_in_minutes
            = $self->get_minutes_from_midnight( $from_hour, $from_minute );
        my $to_in_minutes
            = $self->get_minutes_from_midnight( $to_hour, $to_minute );
        my $time_valid
            = $self->is_minutes_within_one_day($from_in_minutes)
            && $self->is_minutes_within_one_day($to_in_minutes)
            && $from_in_minutes < $to_in_minutes;
        push @{ $self->business_hours },
                    TimeRange->new( from_hour    => $from_hour,
                                    from_minutes => $from_minute,
                                    to_hour      => $to_hour,
                                    to_minutes   => $to_minute
                                  ) if ($time_valid);
        return $time_valid;
    }
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $r = Restaurant->new();
$r->add_holiday( 2019, 1, 1 );
$r->add_bs_hour( 10, 0, 18, 0 );
is( $r->business_hours->[0]->from_hour, 10 );
done_testing();
1;
