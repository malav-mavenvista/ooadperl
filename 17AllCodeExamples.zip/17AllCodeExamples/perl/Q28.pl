use 5.026;
use warnings;
use utf8;

package Artists {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'artists' =>
        ( is => 'ro', isa => 'ArrayRef[Artist]', default => sub { [] } );

    sub get_artist ( $self, $index ) {
        return if ( $index < 0 || $index >= scalar @{ $self->artists } );
        return $self->artists->[$index];
    }

    sub get_artist_name ( $self, $index ) {
        my $n;
        eval { $n = $self->get_artist($index)->name() } or return;
        return $n;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Artist {
    use Moose;
    has 'name' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $a = Artist->new( name => 'vi' );
my $all = Artists->new( artists => [$a] );
is( $all->get_artist_name(0), 'vi' );
ok( !defined $all->get_artist_name(1) );
done_testing();
1;
