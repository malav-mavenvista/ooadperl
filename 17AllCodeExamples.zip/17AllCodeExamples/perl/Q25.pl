use 5.026;
use warnings;
use utf8; 

package Order {
	use Moose; 
	use Math::BigInt;
	use HashMap;
	use feature 'signatures';
	no warnings qw(experimental::signatures);    

	has 'order_id' => (is=>'ro', isa=>'Str', required=>1);
	has 'r1' => (is=>'rw', isa=>'Restaurant');
	has 'c1' => (is=>'rw', isa=>'Customer');
	has 'address' => (is=>'rw', isa=>'Str', default=>q{});
	has 'order_items' => (is=>'ro', isa=>'HashMap', default=>sub{HashMap->new()});

    #get the total amount of this order.	
	sub get_total_amt($self) {
        my $amt = Math::BigInt->bzero(); #total amount
        foreach my $k ($self->order_items->keys_copy) {
        	my $oi = $self->order_items->get($k);
        	$amt->badd(Math::BigInt->new($oi));
        }
        return $amt;
	}

    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More; 
use String;
my $o = Order->new(order_id=>'a');
$o->order_items->put(String->new(value=>"mobile1"), 10);
is ($o->get_total_amt->numify(), 10);
done_testing();
1;