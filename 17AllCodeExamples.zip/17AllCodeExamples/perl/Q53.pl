use 5.026;
use warnings;
use utf8;

package PianoKey {
	use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);
	use constant {
		KEY0=>0,
		KEY1=>1,
		KEY2=>2,
	};

	has 'key_number' => (is=>'ro', isa=>'Int', required=>1);

	sub play_sound($self) {
		if ($self->key_number == __PACKAGE__->KEY0) {
			#play the frequency for KEY0
		}
		elsif ($self->key_number == __PACKAGE__->KEY1) {
			#play the frequency for KEY1
		}
		elsif ($self->key_number == __PACKAGE__->KEY2) {
			#play the frequency for KEY2
		}
	}

	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

package Piano {
	use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);
	has 'rhythm' => (is=>'ro', isa=>'ArrayRef[PianoKey]', default=>sub {[]} );
	sub play($self) {
		$_->play_sound() foreach @{$self->rhythm};
	}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
use Test::More;
my $p1 = PianoKey->new(key_number=> PianoKey->KEY2);
Piano->new(rhythm=>[$p1])->play();
done_testing();
1;