use 5.026;
use warnings;
use utf8;

package PianoKey {
	use Moose;
	use MooseX::ClassAttribute;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

	use constant FREQUENCY_FOR_KEY0 => 123; #some value
	class_has 'Key0' => (is=>'ro', isa=>'Piano',
		default=>sub{PianoKey->new(key_number=>FREQUENCY_FOR_KEY0)});

	use constant FREQUENCY_FOR_KEY1 => 124; #some value
	class_has 'Key1' => (is=>'ro', isa=>'Piano',
		default=>sub{PianoKey->new(key_number=>FREQUENCY_FOR_KEY1)});

	use constant FREQUENCY_FOR_KEY2 => 125; #some value
	class_has 'Key2' => (is=>'ro', isa=>'Piano',
		default=>sub{PianoKey->new(key_number=>FREQUENCY_FOR_KEY2)});

	has '_frequency' => (is=>'ro', isa=>'Int', required=>1);

	sub play_sound($self) {
		my $frequency_to_be_played = $self->_frequency;
		#....
	}
	__PACKAGE__->meta->make_immutable;
	no MooseX::ClassAttribute;
    no Moose;
	1;
}

package Piano {
	use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);
	has 'rhythm' => (is=>'ro', isa=>'ArrayRef[PianoKey]', default=>sub {[]} );
	sub play($self) {
		$_->play_sound() foreach @{$self->rhythm};
	}
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}
use Test::More;
Piano->new(rhythm=>[PianoKey->Key2])->play();
done_testing();
1;