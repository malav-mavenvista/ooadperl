use 5.026;
use warnings;
use utf8;

package ISchedule {
    use Moose::Role;
    requires 'get_duration_in_days', 'print_schedule';
    no Moose::Role;
    1;
}

package WeeklySchedule {
    use Moose;
    use DateTime;
    with 'ISchedule';

    has 'no_weeks'  => ( is => 'ro', isa => 'Int',      required => 1 );
    has 'from_date' => ( is => 'ro', isa => 'DateTime', required => 1 );

    sub get_duration_in_days {
    	my $self = shift;
        return $self->no_weeks;
    }

    sub print_schedule {
        #Print this schedule
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package RangeSchedule {
    use Moose;
    use DateTime;
    with 'ISchedule';

    has 'from_date' => ( is => 'ro', isa => 'DateTime', required => 1 );
    has 'to_date'   => ( is => 'ro', isa => 'DateTime', required => 1 );

    sub get_duration_in_days {
        my $self = shift;
        return $self->to_date()->delta_days( $self->from_date() )
            ->in_units('days');
    }

    sub print_schedule {
        #Print this schedule
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ListSchedule {
    use Moose;
    use DateTime;
    with 'ISchedule';

    has 'date_list' =>
        ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );

    sub get_duration_in_days {
    	my $self = shift;
        return scalar @{ $self->date_list };
    }

    sub print_schedule {
        #Print this schedule
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Course {
    use Moose;
    has 'course_title' => ( is => 'ro', isa => 'Str',       required => 1 );
    has 'schedule'     => ( is => 'ro', isa => 'ISchedule', required => 1 );

    sub get_duration_in_days {
    	my $self = shift;
    	return $self->schedule->get_duration_in_days();
    }

    sub print_schedule {
    	my $self = shift;
    	return $self->schedule->print_schedule();
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $w = WeeklySchedule->new( no_weeks => 2, from_date => DateTime->today() );
my $c = Course->new( course_title => 'UML', schedule => $w );
is( $c->get_duration_in_days, 2 );

my $r = RangeSchedule->new(
    from_date => DateTime->today(),
    to_date   => DateTime->today()->add( days => 7 )
);
$c = Course->new( course_title => 'OOAD', schedule => $r );
is( $c->get_duration_in_days, 7 );

my @days = map { DateTime->today()->add( days => $_ ) } ( 0 .. 3 );
my $l = ListSchedule->new( date_list => \@days );
$c = Course->new(
    course_title => 'Perl',
    schedule     => $l
);
is( $c->get_duration_in_days, 4 );

done_testing();
1;
