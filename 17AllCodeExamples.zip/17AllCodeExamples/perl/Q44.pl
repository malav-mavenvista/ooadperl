use 5.026;
use warnings;
use utf8;

#We need exclusive access to FILE1 and DATABASE1.
#New resources will be added later on. The design should be able
#accommodate these new resource allocation/deallocation easily.

package Ra1 {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    use constant {
        RESOURCE_TYPE_FILE1     => 1,
        RESOURCE_TYPE_DATABASE1 => 2,
    };

    sub allocate ( $self, $resource_type ) {
        my $resource_id = 0;
        if ( $resource_type == __PACKAGE__->RESOURCE_TYPE_FILE1 ) {
            $resource_id = $self->get_free_file();
        }
        elsif ( $resource_type == __PACKAGE__->RESOURCE_TYPE_DATABASE1 ) {
            $resource_id = $self->get_free_database();
        }
        return $resource_id;
    }

    sub free ( $self, $res, $resource_id ) {
        if ( $res == __PACKAGE__->RESOURCE_TYPE_FILE1 ) {
            $self->mark_file_free($resource_id);
        }
        elsif ( $res == __PACKAGE__->RESOURCE_TYPE_DATABASE1 ) {
            $self->mark_database_free($resource_id);
        }
        return $self;
    }

    sub mark_database_free($self, $id) { }
    sub mark_file_free($self, $id)     { }
    sub get_free_file($self)      { }
    sub get_free_database($self)  { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
Ra1->new()->allocate(2);
Ra1->new()->free(2,1);
done_testing();
1;
