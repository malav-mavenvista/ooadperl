use 5.026;
use warnings;
use utf8;

package IAlarm {
    use Moose::Role;
    requires 'turn_on';
    no Moose::Role;
    1;
}

package Cooker {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'IAlarm';
    has 'heat_sensor' => (
        is  => 'rw',
        isa => 'HeatSensor'
    );
    has 'speaker' => (
        is      => 'ro',
        isa     => 'Speaker',
        default => sub { Speaker->new() }
    );

    sub turn_on($self) {
        $self->speaker->frequency( Speaker->HIGH_FREQUENCY );
        $self->speaker->turn_on();
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package HeatSensor {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'alarm' => (
        is  => 'rw',
        isa => 'IAlarm'
    );

    sub check_over_heated($self) {
        if ( $self->is_over_heated() ) { $self->alarm->turn_on() }
    }

    sub is_over_heated($self) {
        #...
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Speaker {
    use Moose;
    use constant HIGH_FREQUENCY => 50_000;
    has 'frequency' => ( is => 'ro', isa => 'Int', default => 0 );
    sub turn_on { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $h = HeatSensor->new();
my $c = Cooker->new();
$h->alarm($c);
$c->heat_sensor($h);
$h->check_over_heated();
done_testing();
1;
