use 5.026;
use warnings;
use utf8;

package TicTacToeGame {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    use constant {
        SIZE   => 3,
        EMPTY  => 0,
        CROSS  => 1,
        CIRCLE => 2,
    };

    has '_board' => (
        is      => 'rw',
        isa     => 'Item',
        lazy    => 1,
        builder => '_create_empty_board'
    );

    sub _create_empty_board($self) {
        my $board = [];
        for my $row ( 0 .. SIZE- 1 ) {
            push @{$board}, $self->create_empty_row();
        }
        $self->_board($board);
    }

    sub create_empty_row($unused) {
        my $row_elements = [];
        for my $col ( 0 .. SIZE- 1 ) { push @{$row_elements}, EMPTY; }
        return $row_elements;
    }

    sub put_x ( $self, $row, $col ) {
        $self->_board->[$row]->[$col] = CROSS;
    }

    sub put_o ( $self, $row, $col ) {
        $self->_board->[$row]->[$col] = CIRCLE;
    }

    sub is_empty ( $self, $row, $col ) {
        return $self->_board->[$row]->[$col] == EMPTY;
    }

    sub is_over($self) {

        # The game is over, if any of the following condition is true
        #   - The board is filled
        #   - Any row is filled with same element
        #   - Any column is filled with same element
        #   - The left or right diagonal is filled with same element.
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $t = TicTacToeGame->new();
$t->put_x( 1, 1 );
$t->put_o( 1, 2 );
ok( $t->is_empty( 0, 0 ) );
done_testing();
1;

#Complete the function is_over using functional programming techniques.
