use 5.026;
use warnings;
use utf8;

package Rental {
    use DateTime;
    use Moose::Role;
    requires 'get_overdue_penalty_rate';
    has 'rent_date'  => ( is => 'rw', isa => 'DateTime' );
    has 'due_date'   => ( is => 'rw', isa => 'DateTime' );
    has 'rental_fee' => ( is => 'rw', isa => 'Num', default => 0 );

    sub is_overdue {
        my $self = shift;
        return DateTime->compare( DateTime->today(), $self->due_date ) > 0;
    }

    sub get_total_fee {
        my $self = shift;
        return $self->is_overdue()
            ? $self->get_overdue_penalty_rate * $self->rental_fee
            : $self->rental_fee;
    }
    no Moose::Role;
    1;
}

package BookRental {
    use Moose;
    with 'Rental';
    has 'book_title' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'author'     => ( is => 'rw', isa => 'Str', default  => q{} );

    use constant PENALTY_RATE => 1.2;
    sub get_overdue_penalty_rate { return PENALTY_RATE; }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package MovieRental {
    use Moose;
    with 'Rental';

    has 'movie_title'    => ( is => 'ro', isa => 'Str', required => 1 );
    has 'classification' => ( is => 'rw', isa => 'Int', default  => 0 );

    use constant PENALTY_RATE => 1.3;
    sub get_overdue_penalty_rate { return PENALTY_RATE; }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b = BookRental->new(
    book_title => 'b',
    rental_fee => 100,
    due_date   => DateTime->today
);
ok( !$b->is_overdue() );
is( $b->get_total_fee, 100 );
my $m = MovieRental->new(
    movie_title => 'c',
    rental_fee  => 100,
    due_date    => DateTime->today
);
ok( !$m->is_overdue() );
is( $m->get_total_fee, 100 );

done_testing();
1;
