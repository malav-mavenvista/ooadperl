use 5.026;
use warnings;
use utf8;

package CustomersInDB {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'conn' => ( is => 'ro', isa => 'Connection' );

    sub get_customer ( $self, $id_number ) {
        my $st = $self->conn->prepare_statement(
            'select * from customer where ID=?');
        try {
            $st->set_string( 1, ( $id_number =~ s/[-,)\/]/ /gr ) );
            my $rs = $st->execute_query();
            #....
        }
        finally {
            $st->close();
        }
    }

    sub add_customer ( $self, $customer ) {
        my $st = $self->conn->prepare_statement(
            'insert into customer values (?,?,?,?)');
        try {
            $st->set_string( 1, ( $customer->id_number =~ s/[-,)\/]/ /gr ) );
            $st->set_string( 2, $customer->name );
            #...
            my $rs = $st->execute_update();
            #....
        }
        finally {
            $st->close();
        }
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#dummy classes for running
package Connection {
    use Moose;
    sub prepare_statement { PreparedStatement->new() }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package PreparedStatement {
    use Moose;
    sub set_string     { }
    sub execute_query  { }
    sub execute_update { }
    sub close          { }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Customer {
    use Moose;
    has 'id_number' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'name'      => ( is => 'rw', isa => 'Str', default => q{} );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $c  = Customer->new();
my $db = CustomersInDB->new( conn => Connection->new() );
$db->add_customer($c);
$db->get_customer( $c->id_number );
done_testing();
1;
