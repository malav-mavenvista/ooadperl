use 5.026;
use warnings;
use utf8;

package Department {
    use Moose;
    use MooseX::ClassAttribute;
    use MooseX::StrictConstructor;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'department_name' => ( is => 'ro', isa => 'Str', required => 1 );

    class_has 'Account' => (
        is      => 'ro',
        isa     => 'Department',
        default => sub { Department->new( department_name => 'Account' ) }
    );
    class_has 'Marketing' => (
        is      => 'ro',
        isa     => 'Department',
        default => sub { Department->new( department_name => 'Marketing' ) }
    );
    class_has 'CustomerServices' => (
        is  => 'ro',
        isa => 'Department',
        default =>
            sub { Department->new( department_name => 'Customer Services' ) }
    );

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no MooseX::ClassAttribute;
    no Moose;
    1;
}

use Test::More;
is( Department->Marketing->department_name, 'Marketing' );
done_testing();
1;
