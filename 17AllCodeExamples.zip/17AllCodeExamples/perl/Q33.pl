use 5.026;
use warnings;
use utf8;

package SurveyData {
    use Moose;
	use feature 'signatures';
	no warnings qw(experimental::signatures);

    #save data to this file
    has 'path' => ( is => 'rw', isa => 'Str', default => q{} );

    #should the file be hidden?
    has 'hidden' => ( is => 'rw', isa => 'Bool', default => 0 );

    #set the path to save the data according to the type of data (t).
    sub set_save_path($self, $t) {
        if ($t == 0) {    #raw data.
                $self->path('c:/application/data/raw.dat');
                $self->hidden(1);
        } elsif ($t == 1) {    #cleaned up data.
                $self->path('c:/application/data/cleanedUp.dat');
                $self->hidden(1);
        } elsif ($t == 2) {    #processed data.
                $self->path('c:/application/data/processed.dat');
                $self->hidden(1);
        } elsif ($t == 3) {    #data ready for publication.
                $self->path('c:/application/data/publication.dat');
                $self->hidden(0);
        }
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $s = SurveyData->new( path => 'a', hidden => 0 );
$s->set_save_path(0);
done_testing();
1;
