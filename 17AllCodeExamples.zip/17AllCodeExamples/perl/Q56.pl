use 5.026;
use warnings;
use utf8;

# This application is about restaurants. Initially we created a
# Restaurant class to represent a restaurant account and
# includes information such as its
#      name, access password, tel and fax number, address.
# The class is like:
#      package Restaurant {
#          has 'name' => (is=>'rw', isa=>'Str');
#	        has 'password' => (is=>'rw', isa=>'Str');
#   		has 'tel_no' => (is=>'rw', isa=>'Str');
#   		has 'fax_no' => (is=>'rw', isa=>'Str');
#   		has 'address' => (is=>'rw', isa=>'Str');
#			....some methods...
#      }
#
# Later, the following requirements are added in sequence:
# 1. After initial registration, the restaurant account is assigned an
#    activation code by the system. Only after the user enters the
#    activation code, the account will become activated.
#    Until then, the account is inactive and login is not allowed.
# 2. If the user would like to change the fax number of the account,
#    the new fax number will not take effect immediately
#    (the existing fax number will remain in effect). Instead,
#    the account is assigned an activation code by the system.
#    Only after the user enters the activation code, the new fax number
#    will take effect.
# 3. A restaurant can be marked as in a certain category
#    (e.g., Chinese restaurant, Portuguese restaurant and etc.).
#    A category is identified by a category ID.
# 4. The user can input the holidays for the restaurant.
# 5. The user can input the business hours for the restaurant.
#
# After implementing all these five requirements, the class has grown
# significantly and become quite complicated as shown below. Our task
# now is to implement the five requirements above in separate classes,
# leaving the original simple Restaurant class unchanged.

package Restaurant {
    use DateTime;
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'name'              => ( is => 'rw', isa => 'Str',  required => 1 );
    has 'password'          => ( is => 'rw', isa => 'Str',  default  => q{} );
    has 'tel_no'            => ( is => 'rw', isa => 'Str',  default  => q{} );
    has 'fax_no'            => ( is => 'rw', isa => 'Str',  default  => q{} );
    has 'address'           => ( is => 'rw', isa => 'Str',  default  => q{} );
    has 'verification_code' => ( is => 'rw', isa => 'Str',  default  => q{} );
    has 'is_activated'      => ( is => 'rw', isa => 'Bool', default  => 0 );
    has 'fax_no_to_be_confirmed' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'is_there_fax_no_to_be_confirmed' =>
        ( is => 'rw', isa => 'Bool', default => 0 );
    has 'cat_id' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'holidays' =>
        ( is => 'ro', isa => 'ArrayRef[DateTime]', default => sub { [] } );
    has 'business_sessions' =>
        ( is => 'ro', isa => 'ArrayRef[Object]', default => sub { [] } );

    sub activate ( $self, $verification_code ) {
        $self->is_activated( $self->verification_code eq $verification_code );
        if ( $self->is_activated && $self->is_there_fax_no_to_be_confirmed ) {
            $self->fax_no( $self->fax_no_to_be_confirmed );
            $self->is_there_fax_no_to_be_confirmed(0);
        }
        return $self;
    }

    sub set_fax_no ( $self, $new_fax_no ) {
        $self->fax_no_to_be_confirmed($new_fax_no);
        $self->is_there_fax_no_to_be_confirmed(1);
        $self->is_activated(0);
        return $self;
    }

    sub is_in_category ( $self, $cat_id ) {
        return $cat_id = $self->cat_id;
    }

    sub add_holiday ( $self, $year, $month, $day ) {
        #...
    }

    sub remove_holiday ( $self, $year, $month, $day ) {
        #...
    }

    sub add_buiness_session ( $self, $from_hour, $from_min, $to_hour, $to_min ) {
        #...
    }

    sub is_in_business_hour ( $self, $time ) {
        #...
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $r = Restaurant->new( name => 'abc' );
$r->activate('');
$r->set_fax_no('123');
done_testing();
1;
