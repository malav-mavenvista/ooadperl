use 5.026;
use warnings;
use utf8;

# The goal is to classify numbers. A number is perfect, if the sum of its
# factors equals the number e.g. 6 is perfect. The factors are 1, 2, 3. 1 + 2 +
# 3 equals 6.
# A number is abundant, if the sum of its factors is greater than
# the number e.g. 12 is abundant. The factors are 1, 2, 3, 4 and 6. 1+2+3+4+6
# is greater than 12.
# A number is deficient, if the sum of its factors is less
# than the number e.g. 10 is deficient. The factors are 1, 2, 5. 1+2+5 is less
# than 10.

package NumberClassifier {
    use Moose;
    use List::Util qw(any sum);
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'number'          => ( is => 'ro', isa => 'Int', required => 1 );
    has '_sum_of_factors' => (
        is      => 'rw',
        isa     => 'Int',
        lazy    => 1,
        builder => '_calculate_factor_sum'
    );

    sub _calculate_factor_sum($self) {
        my $factors = [1];
        for my $i ( 2 .. sqrt $self->number ) {
            if ( $self->is_factor($i) ) { $self->_add_factor( $i, $factors ) }
        }
        $self->_sum_of_factors( sum( @{$factors} ) );
    }

    sub is_factor ( $self, $factor ) {
        return $self->number % $factor == 0;
    }

    sub _add_factor ( $self, $factor, $factors ) {
        unless ( any { $_ == $factor } @{$factors} ) {
            push @{$factors}, $factor;
            push @{$factors}, ( $self->number / $factor );
        }
        return $self;
    }

    sub is_perfect($self) {
        return $self->_sum_of_factors == $self->number;
    }

    sub is_abundant($self) {
        return $self->_sum_of_factors > $self->number;
    }

    sub is_deficient($self) {
        return $self->_sum_of_factors < $self->number;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
my $n = NumberClassifier->new( number => 6 );
ok( $n->is_perfect );
ok( NumberClassifier->new( number => 7 )->is_deficient );
done_testing();
1;
