use 5.026;
use warnings;
use utf8;

# This is an embedded application controlling a cooker.
# In every second, it will check if the cooker is over-heated
# (e.g., short-circuited). If yes it will cut itself off the power
# and make an alarm using its built-in speaker. It will also check
# if the moisture inside is lower than a certain threshold
# (e.g., the rice is cooked). If yes, it will turn its built-in heater
# to 50 degree Celsius just to keep the rice warm.
# In the future, you expect that some more things will need to be
# done in every second.
# Remove the problem in the code.

package Scheduler {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'alarm' =>
        ( is => 'ro', isa => 'Alarm', default => sub { Alarm->new() } );
    has 'heat_sensor' => (
        is      => 'ro',
        isa     => 'HeatSensor',
        default => sub { HeatSensor->new() }
    );
    has 'power_supply' => (
        is      => 'ro',
        isa     => 'PowerSupply',
        default => sub { PowerSupply->new() }
    );
    has 'moisture_sensor' => (
        is      => 'ro',
        isa     => 'MoistureSensor',
        default => sub { MoistureSensor->new() }
    );
    has 'heater' =>
        ( is => 'ro', isa => 'Heater', default => sub { Heater->new() } );

    sub run_in_seprate_thread($self) {
        for ( ;; ) {
            sleep 1;

            #Check if it is over-heated
            if ( $self->heat_sensor->is_over_heated() ) {
                $self->power_supply->turn_off();
                $self->alarm->turn_on();
            }

            #Check if rice is cooked
            if ( $self->moisture_sensor->moisture < 60 ) {
                $self->heater->temperature(50);
            }
        }
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

#Dummy classes to run above code
package Alarm {
    use Moose;
    sub turn_on { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package HeatSensor {
    use Moose;
    sub is_over_heated {1}
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package PowerSupply {
    use Moose;
    sub turn_off { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package MoistureSensor {
    use Moose;
    has 'moisture' => ( is => 'rw', isa => 'Int', default => 0 );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Heater {
    use Moose;
    has 'temperature' => ( is => 'rw', isa => 'Int', default => 0 );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
Scheduler->new()->run_in_seprate_thread();
done_testing();
1;
