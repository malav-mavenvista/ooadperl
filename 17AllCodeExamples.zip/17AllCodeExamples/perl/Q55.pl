use 5.026;
use warnings;
use utf8;

package Form1 {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'combo_box_report_type' => ( is => 'rw', isa => 'JComboBox' );

    sub BUILD ( $self, $args ) {
        $self->combo_box_report_type( JComboBox->new() );
        $self->combo_box_report_type->add_item('r1');
        $self->combo_box_report_type->add_item('r2');
        #...
        $self->combo_box_report_type->add_item('r31c');
    }

    sub process_report1($self) {
        #print some fancy report...
    }

    sub process_report2($self) {
        #print another totally different fancy report...
    }

    #...
    sub process_report31c($self) {
        #print yet another totally different fancy report...
    }

    sub print_report ( $self, $rep_no ) {
        if ( $rep_no eq 'r1' ) {
            $self->process_report1();
        }
        elsif ( $rep_no eq 'r2' ) {
            $self->process_report2();
        }    #...
        elsif ( $rep_no eq 'r31c' ) {
            $self->process_report31c();
        }
    }

    sub on_print_click($self) {
        $self->print_report(
            $self->combo_box_report_type->get_selected_item() );
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package JComboBox {    #dummy class
    use Moose;
    sub add_item          { }
    sub get_selected_item {'r1'}
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
Form1->new()->on_print_click();
done_testing();
1;
