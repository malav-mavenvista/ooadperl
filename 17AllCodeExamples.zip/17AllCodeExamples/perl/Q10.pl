use 5.026;
use warnings;
use utf8;

package UIDialogCustomerMain {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'JDialog';

    has 'btn_order_del'            => ( is => 'ro', isa => 'JButton' );
    has 'btn_cust_change_password' => ( is => 'ro', isa => 'JButton' );

    sub bind_events($self) {
        #...
        my $action = sub {
            my $d = UIDialogCustomerDeleteOrder->new( $self, 'Del Order', 1 );
            $d->pack();
            $d->set_location( 400, 200 );
            $d->set_visible(1);
        };
        $self->btn_order_del->add_action_listener($action);

        my $action2 = sub {
            my $d = UIChangeAccountPW->new( $self, 'chg pw', 1 );
            $d->pack();
            $d->set_location( 400, 200 );
            $d->set_visible(1);
        };
        $self->btn_cust_change_password->add_action_listener($action2);
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIDialogRestaurantMain {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    with 'JDialog';

    has 'btn_change_password' => ( is => 'ro', isa => 'JButton' );

    sub bind_events($self) {
        #...
        my $action = sub {
            my $d = UIChangeAccountPW->new( $self, 'chg pw', 1 );
            $d->pack();
            $d->set_location( 400, 200 );
            $d->set_visible(1);
        };
        $self->btn_change_password->add_action_listener($action);
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#Some dummy classes for above code to compile/run
package JDialog {
    use Moose::Role;
    sub pack                { }
    sub set_location        { }
    sub set_visible         { }
    sub add_action_listener { }
    no Moose::Role;
    1;
}

package JButton {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIDialogCustomerDeleteOrder {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package UIChangeAccountPW {
    use Moose;
    with 'JDialog';
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
#End of dummy classes

use Test::More;
my $button = JButton->new();
my $u      = UIDialogCustomerMain->new(
    btn_order_del            => $button,
    btn_cust_change_password => $button
);
$u->bind_events();
$u = UIDialogRestaurantMain->new( btn_change_password => $button );
$u->bind_events();
done_testing();
1;
