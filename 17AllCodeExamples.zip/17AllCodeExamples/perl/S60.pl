use 5.026;
use warnings;
use utf8;

package NumberClassifier {
    use List::Util qw(any sum);
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub is_factor ( $unused, $number, $factor ) {
        return $number % $factor == 0;
    }

    sub factors ( $unused, $number ) {
        my @factors = (1);
        for my $i ( 2 .. sqrt $number ) {
            if ( __PACKAGE__->is_factor( $number, $i )
                and ( !any { $_ == $i } @factors ) )
            {
                push @factors, $i;
                push @factors, ( $number / $i );
            }
        }
        return \@factors;
    }

    sub sum_of_factors ( $unused, $number ) {
        return sum @{ __PACKAGE__->factors($number) };
    }

    sub is_perfect ( $unused, $number ) {
        return __PACKAGE__->sum_of_factors($number) == $number;
    }

    sub is_abundant ( $unused, $number ) {
        return __PACKAGE__->sum_of_factors($number) > $number;
    }

    sub is_deficient ( $unused, $number ) {
        return __PACKAGE__->sum_of_factors($number) < $number;
    }
    1;
}

use Test::More;
ok( NumberClassifier->is_perfect(6) );
ok( NumberClassifier->is_abundant(12) );
ok( NumberClassifier->is_deficient(10) );
done_testing();
1;
