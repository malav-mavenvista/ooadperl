use 5.026;
use warnings;
use utf8;
use feature 'signatures';
no warnings qw(experimental::signatures);

package Supplier {
    use Moose::Role;
    requires 'get_line';
    no Moose::Role;
    1;
}

package Extracter {
    use Moose::Role;
    requires 'extract_info';
    no Moose::Role;
    1;
}

package AccumulateBookDetails {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'total_price'     => ( is => 'rw', isa => 'Num', default => 0 );
    has 'valid_records'   => ( is => 'rw', isa => 'Int', default => 0 );
    has 'invalid_records' => ( is => 'rw', isa => 'Int', default => 0 );

    sub process ( $self, $supplier_input, $extract_price ) {
        my $line = $supplier_input->get_line();    #skip header
        for ( ;; ) {
            $line = $supplier_input->get_line();
            last if ( !defined $line or length($line) <= 2 );
            my $price = $extract_price->extract_info($line);
            if ( $price > 0 ) {
                $self->valid_records( $self->valid_records + 1 );
            }
            else {
                $self->invalid_records( $self->invalid_records + 1 );
            }
            $self->total_price( $self->total_price + $price );
        }
        return $self;
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ReadEachLineOfFile {
    use Moose;
    use Carp;
    with 'Supplier';
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'file_name' => ( is => 'ro', isa => 'Str', default => 'books.csv' );
    has '_fh'       => ( is => 'rw', isa => 'Item' );

    sub BUILD ( $self, $args ) {
        open my $csv_fh, '<', $self->file_name
            or confess 'Failed to open file in input mode.';
        $self->_fh($csv_fh);
    }
    sub DEMOLISH {
    	my $self = shift;
    	close $self->_fh;
    }
    sub get_line($self) {
        my $fh   = $self->_fh;
        my $line = <$fh>;
        return $line;
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package BookRecord {
    use Moose;
    with 'Extracter';
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub extract_info ( $self, $line ) {
        my ( $isbn, $title, $price ) = split /,/, $line;
        return 0 unless defined $isbn and defined $title and defined $price;
        if ( length($isbn) < 2 || length($title) < 2 ) { return 0 }
        return 0 unless ( $price =~ /^\d+$/ );
        return int $price;
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
my $a = AccumulateBookDetails->new()->process(
			ReadEachLineOfFile->new(), BookRecord->new() );
printf "Total price of all books %g\n", $a->total_price;
printf "Total valid records %d\n",      $a->valid_records;
printf "Total invalid records %d\n",    $a->invalid_records;
1;
