use 5.026;
use warnings;
use utf8;
use Point;

package IShape {
    use Moose::Role;
    requires 'draw';
    no Moose::Role;
    1;
}

package Circle {
    use Moose;
    with 'IShape';
    has 'center' => ( is => 'ro', isa => 'Point', required => 1 );
    has 'radius' => ( is => 'rw', isa => 'Int', default => 0 );
    sub draw {
        my ($self, $graphics) = @_;
        $graphics->draw_circle( $self->center, $self->radius);
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Line {
    use Moose;
    with 'IShape';
    has 'start' => ( is => 'ro', isa => 'Point', required => 1 );
    has 'end' => ( is => 'rw', isa => 'Point', required=>1 );
    sub draw {
        my ($self, $graphics) = @_;
        $graphics->draw_line( $self->start, $self->end );
    }
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Rectangle {
    use Moose;
    with 'IShape';
    has 'lower_left' => ( is => 'ro', isa => 'Point', required => 1 );
    has 'upper_right' => ( is => 'rw', isa => 'Point', required=>1 );
        sub draw {
        my ($self, $graphics) = @_;
        $graphics->draw_line( $self->lower_left, $self->upper_right );
        #Remaining lines
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}


package CADApp {
    use Moose;

    sub draw_shapes {
        my ( $self, $graphics, @shapes ) = @_;
        foreach my $shape (@shapes) {
            $shape->draw($graphics);
        }
        return $self;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $ca     = CADApp->new();
my $p1     = Point->new( x => 1, y => 2 );
my $p2     = Point->new( x => 3, y => 5 );
my $s1     = Line->new(start => $p1, end => $p2 );
my $s2     = Circle->new( center => $p1, radius => 3 );
my $s3     = Rectangle->new( lower_left => $p1, upper_right => $p2 );
my @shapes = ( $s1, $s2, $s3 );
$ca->draw_shapes( 'graphics not present. Demo only', @shapes );
done_testing();
1;
