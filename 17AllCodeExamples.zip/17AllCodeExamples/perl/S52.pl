use 5.026;
use warnings;
use utf8;

package IPayment {
    use Moose::Role;
    use constant TAX_RATE => 0.1;
    requires 'get_pre_taxed_amount', 'get_tax_rate';

    has 'units' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'rate'  => ( is => 'ro', isa => 'Num', required => 1 );

    sub get_billable_amount {
        my $self = shift;
        return $self->get_pre_taxed_amount()
            * ( 1.0 + $self->get_tax_rate() );
    }

    sub get_normal_amount {
        my $self = shift;
        return $self->units * $self->rate;
    }

    no Moose::Role;
    1;
}

package NormalPayment {
    use Moose;
    with 'IPayment';

    sub get_pre_taxed_amount {
        my $self = shift;
        return $self->get_normal_amount();
    }

    sub get_tax_rate {
        return IPayment->TAX_RATE;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package PaymentForSeniorCitizen {
    use Moose;
    with 'IPayment';

    sub get_pre_taxed_amount {
        my $self = shift;
        return $self->get_normal_amount() * 0.8;
    }

    sub get_tax_rate {
        return IPayment->TAX_RATE - 0.05;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $np = NormalPayment->new( units => 10, rate => 2 );
is( $np->get_billable_amount, 22 );
my $sp = PaymentForSeniorCitizen->new( units => 10, rate => 2 );
is( $sp->get_billable_amount, 16.8 );
done_testing();
1;
