use 5.026;
use warnings;
use utf8;

package Board {
    use Moose;
    use StringBuilder;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    sub board_representation($self) {
        my $buf = StringBuilder->new();
        foreach my $location ( @{ $self->squares() } ) {
            $location->add_to($buf);
        }
        return $buf->to_string();
    }
    sub squares {
        return [ Location->new() ]    #some list of locations
    }
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Piece {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'representation' =>
        ( is => 'ro', isa => 'Str', default => 'something' );
    sub character($self) {
        return substr $self->representation, 0, 1;
    }
    sub add_to ( $self, $buf ) {
        $buf->append( $self->character() );
        return $self;
    }
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package Location {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'current' =>
        ( is => 'ro', isa => 'Piece', default => sub { Piece->new } );
    sub add_to ( $self, $buf ) {
        $self->current->add_to($buf);
        return $self;
    }
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
Board->new()->board_representation();
done_testing();
1;
