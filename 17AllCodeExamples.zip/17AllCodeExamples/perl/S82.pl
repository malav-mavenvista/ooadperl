use 5.026;
use warnings;
use utf8;

# Point out the problem in the code below. Further suppose that you
# need to reuse the fax machine code in another application. What should
# you do?

package MainApp {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'fax_no' => ( is => 'rw', isa => 'Str', default => q{} );

    sub main($self) {
        FaxMachine->new( station_id => $self->fax_no )
            ->send_fax( '783675', 'hello' );
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package FaxMachine {
    use Moose;
    use Try::Tiny;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'station_id' => ( is => 'ro', isa => 'Str', required => 1 );

    sub send_fax ( $self, $to_fax_no, $msg ) {
        my $hardware = FaxMachineHardware->new();
        $hardware->station_id( $self->station_id );
        $hardware->receipient_fax_no($to_fax_no);
        $hardware->start();
        try {
            my $total_pages = 0;    #initiailze based on $msg.
            for ( 1 .. $total_pages ) {

                #send the next page
            }
        }
        finally {
            $hardware->done();
        };
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package FaxMachineHardware {    #dummy class
    use Moose;
    has 'station_id'        => ( is => 'rw', isa => 'Str' );
    has 'receipient_fax_no' => ( is => 'rw', isa => 'Str' );
    sub start { }
    sub done  { }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
MainApp->new()->main();
done_testing();
1;
