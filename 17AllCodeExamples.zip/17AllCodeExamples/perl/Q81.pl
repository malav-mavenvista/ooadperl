use 5.026;
use warnings;
use utf8;

# Point out the problem in the code below. Further suppose that you
# need to reuse the file copier in a text mode file copying application
# that will display the progress in its text console as an integer.
# What should you do?

package MainApp {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'progress_bar' => (
        is      => 'rw',
        isa     => 'ProgressBar',
        default => sub { ProgressBar->new() }
    );

    sub main($self) {
        my $fc = FileCopier->new( app => $self );
        $fc->copy_file( 'f1.doc', 'f2.doc' );
    }

    sub update_progress_bar ( $self, $no_bytes_copies, $size_of_source ) {
        $self->progress_bar->percentage(
            $no_bytes_copies * 100 / $size_of_source );
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package FileCopier {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);
    has 'app' => ( is => 'ro', isa => 'MainApp', required => 1 );

    sub copy_file ( $self, $source, $target ) {
        my $size_of_source = 0;    #Set file size
        for ( my $i = 0; $i < $size_of_source; ) {
            my $n = 512;
            #read n (<= 512) bytes from source.
            #write n bytes to target.
            $i += $n;
            $self->app->update_progress_bar( $i, $size_of_source );
        }
    }
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

package ProgressBar {
    use Moose;
    has 'percentage' => ( is => 'rw', isa => 'Num', default => 0 );
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
MainApp->new()->main();
done_testing();
1;
