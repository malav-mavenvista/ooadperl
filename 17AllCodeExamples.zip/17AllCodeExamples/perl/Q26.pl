use 5.026;
use warnings;
use utf8;

package Board {
    use Moose;

    sub board_representation {
        my $self = shift;
        my $buf  = q{};
        foreach my $location ( @{ $self->squares() } ) {
            $buf .= substr $location->current->representation(), 0, 1;
        }
        return $buf;
    }

    sub squares {
        return [ Location->new() ]    #some list of locations
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Piece {
    use Moose;
    has 'representation' =>
        ( is => 'ro', isa => 'Str', default => 'something' );
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
package Location {
    use Moose;
    has 'current' =>
        ( is => 'ro', isa => 'Piece', default => sub { Piece->new } );
    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}
use Test::More;
Board->new()->board_representation();
done_testing();
1;
