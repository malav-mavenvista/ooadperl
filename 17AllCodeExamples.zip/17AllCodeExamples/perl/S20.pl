use 5.026;
use warnings;
use utf8;

package InchToPointConvertor {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    use constant POINTS_PER_INCH => 72;

    sub convert_to_points ( $unused, $inch ) {
        return $inch * POINTS_PER_INCH;
    }

    #Other attributes and methods here.
    __PACKAGE__->meta->make_immutable;
    no Moose;
    1;
}

use Test::More;
is( InchToPointConvertor->convert_to_points(1),        72 );
is( InchToPointConvertor->new()->convert_to_points(1), 72 );
done_testing();
1;
