use 5.026;
use warnings;
use utf8;

package BookRentals {
    use Moose;
    use feature 'signatures';
    no warnings qw(experimental::signatures);

    has 'rentals' =>
        ( is => 'ro', isa => 'ArrayRef[BookRental]', default => sub { [] } );

    sub count_rentals($self) { scalar @{ $self->rentals } }
    sub get_rental_at ( $self, $position ) { $self->rentals->[$position] }

    sub print_overdue_rentals($self) {
        for ( my $i = 0; $i < $self->count_rentals; $i++ ) {
            my $rental = $self->get_rental_at($i);
            if ($rental->is_overdue()
                # and some complex condition here
                )
            {
                print $rental;
            }
        }
    }

    sub count_overdue_rentals($self) {
        my $count = 0;
        for ( my $i = 0; $i < $self->count_rentals; $i++ ) {
            my $rental = $self->get_rental_at($i);
            if ($rental->is_overdue()
                # and same complex condition here again
                )
            {
                $count++;
            }
        }
        return $count;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#dummy classes for running script
package BookRental {
    use Moose;
    sub is_overdue {1}
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b = BookRentals->new( rentals => [ BookRental->new() ] );
$b->print_overdue_rentals();
$b->count_overdue_rentals();
done_testing();
1;
