use 5.026;
use warnings;
use utf8;
use Point;

package IShape {
    use Moose::Role;
    requires 'draw';
    no Moose::Role;
    1;
}

package Line {
    use Moose;
    with 'IShape';

    has 'start_point' => ( is => 'ro', isa => 'Point', required => 1 );
    has 'end_point'   => ( is => 'ro', isa => 'Point', required => 1 );

    sub draw {
        my ( $self, $graphics ) = @_;
        say 'Line drawn';
        #$graphics->draw_line($self->start_point, $self->end_point);
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Rectangle {
    use Moose;
    with 'IShape';

    has 'lower_left_corner'  => ( is => 'ro', isa => 'Point', required => 1 );
    has 'upper_right_corner' => ( is => 'ro', isa => 'Point', required => 1 );

    sub draw {
        my ( $self, $graphics ) = @_;
        say 'Rectangle drawn';
        #draw the four edges by calling $graphics->draw_line();
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Circle {
    use Moose;
    with 'IShape';

    has 'center' => ( is => 'ro', isa => 'Point', required => 1 );
    has 'radius' => ( is => 'ro', isa => 'Int',   required => 1 );

    sub draw {
        my ( $self, $graphics ) = @_;
        say 'Circle drawn';
        #draw the four edges by calling $graphics->draw_circle();
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CADApp {
    use Moose;

    sub draw_shapes {
        my ( $self, $graphics, @shapes ) = @_;
        foreach my $shape (@shapes) { $shape->draw($graphics) }
        return $self;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $ca = CADApp->new();
my $p1 = Point->new( x => 1, y => 2 );
my $p2 = Point->new( x => 3, y => 5 );
my $s1 = Line->new( start_point => $p1, end_point => $p2 );
my $s2 = Circle->new( center => $p1, radius => 3 );
my $s3 = Rectangle->new( lower_left_corner => $p1, upper_right_corner => $p2 );
my @shapes = ( $s1, $s2, $s3 );
$ca->draw_shapes( 'graphics not present. Demo only', @shapes );

done_testing();
1;
