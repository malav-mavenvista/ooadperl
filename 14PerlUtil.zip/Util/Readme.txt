This folder contains some common perl classes used by other perl examples.
To use this folder, give
	perl -IUtil <<perl file>>