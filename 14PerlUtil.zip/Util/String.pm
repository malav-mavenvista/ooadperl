package String;
use 5.026;
use utf8;
use Moose;
use MooseX::StrictConstructor;

with 'IEquals';

has 'value' => ( is => 'ro', isa => 'Str', required => 1 );

sub to_string {
    my $self = shift;
    return $self->value;
}

sub equals {
    my $self  = shift;
    my $other = shift;
    return 1 if $self == $other;
    return 0 if ref $other ne ref $self;
    return $self->value eq $other->value;
}

no Moose;
__PACKAGE__->meta->make_immutable;
1;
