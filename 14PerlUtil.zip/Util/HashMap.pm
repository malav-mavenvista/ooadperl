package HashMap;
use 5.026;
use utf8;
use namespace::autoclean;
use Moose;
use MooseX::StrictConstructor;
use List::MoreUtils qw(firstidx);
use Carp;

has '_keys' =>
    ( is => 'ro', isa => 'ArrayRef[IEquals]', default => sub { [] } );
has '_values' =>
    ( is => 'ro', isa => 'ArrayRef[Item]', default => sub { [] } );

sub put {
    my ( $self, $key, $value ) = @_;
    my $position = $self->_key_position($key);
    $position >= 0
        ? ( $self->_values->[$position] = $value )
        : $self->_add_new_pair( $key, $value );
    return $self;
}

sub _add_new_pair {
    my ( $self, $key, $value ) = @_;
    push @{ $self->_keys },   $key;
    push @{ $self->_values }, $value;
}

sub get {
    my ( $self, $key ) = @_;
    my $position = $self->_key_position($key);
    return ( $position >= 0 ) ? $self->_values->[$position] : undef;
}

sub contains_key {
    my ( $self, $key ) = @_;
    return $self->_key_position($key) >= 0;
}

sub is_empty {
    my $self = shift;
    return $self->size > 0;
}

sub size {
    my $self = shift;
    return scalar @{ $self->_keys };
}

sub keys_copy {
    my $self = shift;
    return @{ $self->_keys };
}

sub remove {
    my ( $self, $key ) = @_;
    $self->_delete_valid_position( $self->_key_position($key) );
    return $self;
}

sub _delete_valid_position {
    my ( $self, $position ) = @_;
    return if $position < 0;
    splice @{ $self->_keys },   $position, 1;
    splice @{ $self->_values }, $position, 1;
}

sub _key_position {
    my ( $self, $key ) = @_;
    return firstidx { $_->equals($key) } @{ $self->_keys };
}
__PACKAGE__->meta->make_immutable;
1;

#Something equivalent of Java LinkedHashMap here.
#A very simple algorithm has been used here.
#For large number of entries in this Hashmap, it is
#better to use hashCode and equals both like in Java.
