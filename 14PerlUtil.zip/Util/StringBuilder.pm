package StringBuilder;
use 5.026;
use utf8;
use Moose;
use MooseX::StrictConstructor;
use feature 'signatures';
no warnings qw(experimental::signatures);

has 'value' => ( is => 'rw', isa => 'Str', default => q{} );

sub append ( $self, $string_at_end ) {
    $self->value( $self->value . $string_at_end );
    return $self;
}

sub char_at ( $self, $index ) {
    return substr $self->value, $index, 1 ;
}

sub insert ( $self, $offset, $str ) {
    $self->value(
              substr( $self->value, 0, $offset )
            . $str
            . substr( $self->value, $offset ) );
    return $self;
}

sub to_string($self) {
    return $self->value;
}

no Moose;
__PACKAGE__->meta->make_immutable;
1;

#Something similar to StringBuilder class of Java.
#Other functions can be added.
