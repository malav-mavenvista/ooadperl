use 5.026;
use warnings;
use utf8;
package ICollection {
	use Moose::Role;
	requires 'equals', 'add';
	no Moose::Role;
	1;
}
package IList {
	use Moose::Role;
	requires 'get';
	with 'ICollection';
	no Moose::Role;
	1;
}
package AbstractList {
	use Moose::Role;
	with 'IList';
	sub equals {
		#...
	}
	sub add {
		#...
	}
	no Moose::Role;
	1;
}
package ArrayList {
	use Moose;
	with 'AbstractList';
    #Other attributes and methods here.
    sub get {
    	print "Get called\n";
    }
    sub add {
    	print "Add called\n";
    }
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More;
my $al = ArrayList->new();
$al->get();
$al->add();
$al->equals();
done_testing();
1;