use 5.026;
use warnings;
use utf8;

package Date {
    use Moose;

    has 'day'   => ( is => 'ro', isa => 'Int', required => 1 );
    has 'month' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'year'  => ( is => 'ro', isa => 'Int', required => 1 );

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Boolean {
    use Moose;

    has 'value' => ( is => 'ro', isa => 'Bool', required => 1 );

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package OrderLine {
    use Moose;

    #Attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use Moose;
    has 'is_prepaid' => (
        is      => 'rw',
        isa     => 'Boolean',
        writer  => '_set_is_prepaid',
        default => sub { Boolean->new( value => 0 ) },
    );
    has 'date_received' =>
        ( is => 'rw', isa => 'Maybe[Date]', writer => '_set_date_received' );
    has '_line_items' =>
        ( is => 'ro', isa => 'ArrayRef[OrderLine]', default => sub { [] } );

    sub add_order_line {
        my ( $self, $order_line ) = @_;
        push @{ $self->_line_items }, $order_line;
        return $self;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $date1  = Date->new( year => 2019, month => 11, day => 7 );
my $order1 = Order->new(
    is_prepaid    => Boolean->new( value => 1 ),
    date_received => $date1
);
ok( $order1->is_prepaid );
is( scalar @{ $order1->_line_items }, 0 );
$order1->add_order_line( OrderLine->new() );
is( scalar @{ $order1->_line_items }, 1 );

my $order2 = Order->new( date_received => $date1 );
ok( !$order2->is_prepaid->value );
done_testing();
1;