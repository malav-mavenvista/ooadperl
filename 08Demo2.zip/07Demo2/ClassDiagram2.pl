use 5.026;
use warnings;
use utf8;

package Employee {
    use Moose;

    #Attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Customer {
    use Moose::Role;

    has 'name'    => ( is => 'ro', isa => 'Str' );
    has 'address' => ( is => 'rw', isa => 'Str', default => q{} );

    sub get_credit_rating {
        'code not shown here';
    }

    #Other attributes and methods here.
    no Moose::Role;
    1;
}

package PersonalCustomer {
    use Moose;
    with 'Customer';
    has 'credit_card_number' => (
        is      => 'rw',
        isa     => 'Str',
        default => q{},
        writer  => '_set_credit_card_number',
    );

    sub get_credit_rating {
        return 'poor';
    }

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CorporateCustomer {
    use Moose;
    with 'Customer';

    has 'contact_name' => (
        is      => 'rw',
        isa     => 'Str',
        default => q{},
        writer  => '_set_contact_name',
    );
    has 'credit_rating' => (
        is      => 'rw',
        isa     => 'Str',
        default => q{},
        writer  => '_set_credit_rating',
    );
    has 'credit_limit' => (
        is      => 'rw',
        isa     => 'Num',
        default => 0,
        writer  => '_set_credit_limit',
    );
    has 'sales_rep' => ( is => 'rw', isa => 'Employee' );

    sub bill_for_month {
        my ( $self, $month ) = @_;
        my $bill_amount = 0;

        #Compute bill here
        return $bill_amount;
    }

    sub remind {
        my $self = shift;

        #Send reminder
        return $self;
    }

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Product {
    use Moose;

    #Attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Money {
    use Moose;

    #Attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package OrderLine {
    use Moose;

    has 'quantity' => ( is => 'ro', isa => 'Int',     default  => 1 );
    has 'price'    => ( is => 'ro', isa => 'Money',   required => 1 );
    has 'product'  => ( is => 'ro', isa => 'Product', required => 1 );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use DateTime;
    use Moose;
    has 'date_received' =>
        ( is => 'rw', isa => 'DateTime', writer => '_set_date_received' );
    has 'is_prepaid' => (
        is      => 'rw',
        isa     => 'Bool',
        writer  => '_set_is_prepaid',
        default => 0,
    );
    has 'number' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'price'  => (
        is      => 'rw',
        isa     => 'Money',
        default => sub { Money->new() },
        writer  => '_set_price',
    );
    has '_line_items' =>
        ( is => 'ro', isa => 'ArrayRef[OrderLine]', default => sub { [] } );

    sub dispatch {
        my $self = shift;

        #Dispatch order
        return $self;
    }

    sub close {
        my $self = shift;

        #Close order
        return $self;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;

my $corp_cust = CorporateCustomer->new( name => 'Vijay' );
ok( $corp_cust->does('Customer') );
my $pers_cut = PersonalCustomer->new( name => 'Vi' );
is( $pers_cut->get_credit_rating, 'poor' );
done_testing();
1;
