use 5.026;
use warnings;
use utf8;

package Product {
    use Moose;
    with 'IEquals';

    has 'id'   => ( is => 'ro', isa => 'Int', required => 1 );
    has 'name' => ( is => 'ro', isa => 'Str', required => 1 );

    #Attributes and methods here
    sub equals {
        my $self  = shift;
        my $other = shift;
        return 1 if $self == $other;
        return 0 if ref $other ne ref $self;
        return ($self->id == $other->id and $self->name eq $other->name)? 1 : 0;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package OrderLine {
    use Moose;

    has 'amount' => ( is => 'ro', isa => 'Num', required => 1 );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use Moose;
    use HashMap;
    has '_line_item' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );

    sub add_order_line {
        my ( $self, $product, $order_line ) = @_;
        $self->_line_item->put( $product, $order_line );
        return $self;
    }

    sub get_order_line {
        my ( $self, $product ) = @_;
        return $self->_line_item->get($product);

    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;

my $prod1 = Product->new( id => 1, name => 'mobile' );
my $prod2 = Product->new( id => 1, name => 'mobile' );
my $ol     = OrderLine->new( amount => 10 );
my $order1 = Order->new();
my $ol2    = $order1->add_order_line( $prod1, $ol )->get_order_line($prod2);
ok( $ol == $ol2 );

done_testing();
1;

#To run this program, keep HashMap and IEquals is some dir and give
#	perl -I<<dir>> <<this file>>
