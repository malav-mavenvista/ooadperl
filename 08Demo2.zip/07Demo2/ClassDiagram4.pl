use 5.026;
use warnings;
use utf8;

package Party {
    use Moose::Role;

    has 'location' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose::Role;
    1;
}

package Person {
    use Moose;
    with 'Party';
    has 'name' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Organization {
    use Moose;
    with 'Party';

    has '_children' =>
        ( is => 'ro', isa => 'ArrayRef[Party]', default => sub { [] } );

    sub add_child {
        my ( $self, $party ) = @_;
        push @{ $self->_children }, $party;
        return $self;
    }

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Data::Dumper;

my $don  = Person->new( name => 'Don',  location => 'Champaign' );
my $john = Person->new( name => 'John', location => 'Champaign' );
my $apps  = Organization->new( location => 'Saba' );
my $tools = Organization->new( location => 'Chicago' );
$tools->add_child($don)->add_child($john);
my $engineering = Organization->new( location => 'Boston' );
$engineering->add_child($tools)->add_child($apps);

print Dumper($engineering);
1;
