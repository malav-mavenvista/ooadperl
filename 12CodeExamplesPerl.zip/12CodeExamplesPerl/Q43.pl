use 5.026;
use warnings;
use utf8;

package Customer {
    use Moose;

    has 'home_address' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'work_address' => ( is => 'rw', isa => 'Str', default => q{} );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use Moose;

    has 'order_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'customer_placing_order' =>
        ( is => 'ro', isa => 'Customer', required => 1 );

    #"H": deliver to home address of the customer.
    #"W": deliver to work address of the customer.
    #"O": deliver to the address specified here.
    has 'address_type' => ( is => 'rw', isa => 'Str', required => 1 );

    #address if address_type is "O"
    has 'other_address' => ( is => 'rw', isa => 'Str', default => q{} );

    sub get_delivery_address {
        my $self = shift;
        return $self->customer_placing_order->home_address
            if ( $self->address_type eq 'H' );
        return $self->customer_placing_order->work_address
            if ( $self->address_type eq 'W' );
        return $self->other_address
        	if ( $self->address_type eq 'O' );
        return; 
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $c = Customer->new( home_address => 'Mumbai', work_address => 'Ahmedabad' );
my $o = Order->new(
    order_id               => 'o1',
    customer_placing_order => $c,
    address_type           => 'H',
    other_address          => 'India'
);

is( $o->get_delivery_address, 'Mumbai', 'Home address' );
$o->address_type('W');
is( $o->get_delivery_address, 'Ahmedabad', 'Work address' );
$o->address_type('O');
is( $o->get_delivery_address, 'India', 'Other address' );

done_testing();
1;
