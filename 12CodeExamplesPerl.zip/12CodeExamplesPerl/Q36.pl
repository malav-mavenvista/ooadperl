use 5.026;
use warnings;
use utf8;

package Currency {
    use Moose;

    use constant {
        USD    => 0,
        RMB    => 1,    #Chinese currency
        ESCUDO => 2     #Portuguese currency
    };
    has 'currency_code' => ( is => 'ro', isa => 'Int', required => 1 );

    sub format {
        my ( $self, $amount ) = @_;
        if ( $self->currency_code == USD ) {
            #return something like $1,200
        }
        elsif ( $self->currency_code == RMB ) {
            #return something like RMB1,200
        }
        elsif ( $self->currency_code == ESCUDO ) {
            #return something like $1.200
        }
        return;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $cu = Currency->new( currency_code => Currency::USD );
$cu->format(1200);
done_testing();
1;
