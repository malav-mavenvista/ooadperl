use 5.026;
use warnings;
use utf8;

package ICurrency {
    use Moose::Role;
    requires 'format_currency';
    no Moose::Role;
    1;
}

package USDCurrency {
    use Moose;
    with 'ICurrency';

    sub format_currency {
        my ( $self, $amount ) = @_;
        return;    #something like $1,200
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package RMBCurrency {
    use Moose;
    with 'ICurrency';

    sub format_currency {
        my ( $self, $amount ) = @_;
        return;    #something like RMB1,200
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ESCUDOCurrency {
    use Moose;
    with 'ICurrency';

    sub format_currency {
        my ( $self, $amount ) = @_;
        return;    #something like $1.200
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $cu = USDCurrency->new();
$cu->format_currency(1200);
done_testing();
1;
