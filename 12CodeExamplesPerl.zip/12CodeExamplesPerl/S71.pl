use 5.026;
use warnings;
use utf8;

package Course {
    use Moose;
    has 'title' => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CourseCatalog {
    use Moose;
    use String;
    use HashMap;
    has '_map' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new } );

    #Some attributes and methods here.
    sub add_course {
        my ( $self, $course ) = @_;
        my $key = String->new( value => $course->title );
        $self->_map->put( $key, $course );
        return $self;
    }

    sub find_course {
        my ( $self, $title ) = @_;
        my $key = String->new( value => $title );
        return $self->_map->get($key);
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;

#To run this program use "perl -IUtil <<filename>>"
my $c   = Course->new( title => 'vi' );
my $cat = CourseCatalog->new();
is( $cat->add_course($c),           $cat, 'Course added' );
is( $cat->find_course( $c->title ), $c,   'Course retrieved' );
done_testing();
1;
