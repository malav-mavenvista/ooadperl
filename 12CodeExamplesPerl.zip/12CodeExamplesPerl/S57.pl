use 5.026;
use warnings;
use utf8;

package Student {
    use Moose;
    use DateTime;

    has 'student_id'    => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'name'          => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'date_of_birth' => ( is => 'ro', isa => 'DateTime', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Enrollment {
    use Moose;
    use DateTime;
    has 'student_id'  => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'course_code' => ( is => 'ro', isa => 'Str',      required => 1 );
    has 'enroll_date' => ( is => 'ro', isa => 'DateTime', required => 1 );
    has 'payment'     => ( is => 'rw', isa => 'Num',      default  => 0 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Enrollments {
    use Moose;

    has '_enrollments' =>
        ( is => 'ro', isa => 'ArrayRef[Enrollment]', default => sub { [] } );

    sub enroll {
        my ( $self, $student_id, $course_code, $enroll_date, $payment ) = @_;
        my $enrollment = Enrollment->new(
            student_id  => $student_id,
            course_code => $course_code,
            enroll_date => $enroll_date,
            payment     => $payment
        );

        #Add $enrollent to $self->_enrollments
        return $self;
    }

    sub unenroll {
        my ( $self, $student_id, $course_code ) = @_;

        #...
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package StudentManagementSystem {
    use Moose;

    has '_students' =>
        ( is => 'ro', isa => 'ArrayRef[Student]', default => sub { [] } );
    has '_enrollments' => ( is => 'ro', isa => 'Enrollments', required => 1 );

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $s = Student->new(
    student_id    => 1,
    name          => 'Vijay',
    date_of_birth => DateTime->now
);
ok( defined $s, 'Student created' );

done_testing();
1;