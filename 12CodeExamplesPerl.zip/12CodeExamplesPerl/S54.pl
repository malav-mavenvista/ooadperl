use 5.026;
use warnings;
use utf8;

package IAccount {
    use Moose::Role;
    requires 'can_login';
    no Moose::Role;
    1;
}

package UserAccount {
    use Moose;
    with 'IAccount';

    has 'expired_date' => ( is => 'rw', isa => 'DateTime', required => 1 );

    sub can_login {
        my $self = shift;
        return $self->is_account_expired();
    }

    sub is_account_expired {
        my $self = shift;
        return DateTime->compare( DateTime->today, $self->expired_date ) >= 0;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package AdminAccount {
    use Moose;
    with 'IAccount';

    has 'has_login' => ( is => 'rw', isa => 'Bool', default => 0 );

    sub can_login {
        my $self = shift;
        return !$self->is_trying_multi_login();
    }

    sub is_trying_multi_login {
        my $self = shift;
        return $self->has_login;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ERPApp {
    use Moose;
    use DateTime;

    sub check_login_issue {
        my ( $self, $account ) = @_;
        return $account->can_login();
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $a   = UserAccount->new( expired_date => DateTime->today() );
my $app = ERPApp->new();
ok( $app->check_login_issue($a) );
$a = AdminAccount->new();
ok( $app->check_login_issue($a) );

done_testing();
1;
