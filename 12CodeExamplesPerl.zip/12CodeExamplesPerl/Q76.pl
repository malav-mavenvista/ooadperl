use 5.026;
use warnings;
use utf8;

#Deep inheritance hierarchy example
package PricingService {
    use Moose::Role;
    use List::Util qw(sum0);
    requires qw(calculate_discount calculate_product_price apply_additional_discounts);

    sub calculate_price {
        my ( $self, $shopping_basket, $user, $voucher ) = @_;
        my $discount = $self->calculate_discount($user);
        my $total = sum0
            map { $self->calculate_product_price( $_->product, $_->quanity ) }
            @{$shopping_basket->items()};
        $total += $self->apply_additional_discounts( $total, $user, $voucher );
        return $total * ( ( 100 - $discount ) / 100 );
    }
    no Moose::Role;
    1;
}

package UserDiscountPricingService {
    use Moose::Role;
    with 'PricingService';

    sub calculate_discount {
        my ( $self, $user ) = @_;
        my $discount = $user->is_prime() ? 10 : 0;
        return $discount;
    }
    no Moose::Role;
    1;
}

package VoucherPricingService {
    use Moose::Role;
    with 'UserDiscountPricingService';
    has 'voucher_service' => ( is => 'rw', isa => 'VoucherService' );

    sub apply_additional_discounts {
        my ( $self, $total, $user, $voucher ) = @_;
        my $voucher_value = $self->voucher_service->get_voucher_value($voucher);
        my $total_after_value = $total - $voucher_value;
        return $total_after_value > 0 ? $total_after_value : 0;
    }
    no Moose::Role;
    1;
}

package StandardPricingService {
    use Moose;
    with 'VoucherPricingService';

    sub calculate_product_price {
        my ( $self, $product, $quantity ) = @_;
        return $product->price * $quantity;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BoxingDayPricingService {
    use Moose;
    with 'VoucherPricingService';
    use constant BOXING_DAY_DISCOUNT => 0.60;

    sub calculate_product_price {
        my ( $self, $product, $quantity ) = @_;
        return $product->price * $quantity * BOXING_DAY_DISCOUNT;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#To avoid compilation/execution error, the following empty classes are created.
package Product {
    use Moose;
    has 'price' => ( is => 'ro', isa => 'Num', required => 1 );
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package VoucherService {
    use Moose;
    sub get_voucher_value {
        return 0;
    }
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package User {
    use Moose;
    sub is_prime {
        return 0;
    }
    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package Item {
    use Moose;
    has 'product' => ( is => 'rw', isa => 'Product' );
    has 'quanity' => ( is => 'rw', isa => 'Num' );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
package ShoppingBasket {
    use Moose;
    has 'items' =>
        ( is => 'ro', isa => 'ArrayRef[Item]', default => sub { [] } );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
#end of empty classes

use Test::More;
my $sps = StandardPricingService->new();
$sps->voucher_service( VoucherService->new() );
$sps->calculate_price( ShoppingBasket->new(), User->new(), q{} );
my $bps = BoxingDayPricingService->new();
$bps->calculate_product_price( Product->new(price=>1), 1 );
done_testing();
1;
