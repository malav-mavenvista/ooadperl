use 5.026;
use warnings;
use utf8;

#Remove the problem in code below.
#Assume that PropertyFileWriter is not used anywhere else
#other than class App.

package FileWriter {
    use Moose;
    has 'path' => ( is => 'ro', isa => 'Str', required => 1 );

    sub write_line {
        my ( $self, $line ) = @_;
        #Write $line to some disk file
        return $self;
    }

    sub close_file {
        #close file
    }

    #Some attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package PropertyFileWriter {
    use Moose;
    extends 'FileWriter';

    sub write_entry {
        my ( $self, $key, $value ) = @_;
        $self->write_line( "$key=$value\n" );
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package App {
    use Moose;
    use Try::Tiny;

    sub make_property_file {
        my $self = shift;
        my $fw   = PropertyFileWriter->new( path => 'f1.properties' );
        try {
            $fw->write_entry( 'conference.abc', '10' );
            $fw->write_entry( 'xyz',            'hello' );
        	return $self;
        }
        finally {
            $fw->close_file();
        }
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $app = App->new();
$app->make_property_file();
done_testing();
1;
