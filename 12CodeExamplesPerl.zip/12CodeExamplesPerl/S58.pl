use 5.026;
use warnings;
use utf8;

package Server {
    use Moose;

    has 'name'            => ( is => 'ro', isa => 'Str', required => 1 );
    has 'cpu_model'       => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'ram_size_in_GB'  => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'disk_size_in_GB' => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'ip_address'      => ( is => 'rw', isa => 'Str', default  => q{} );

    with 'IEquals';

    sub equals {
        my $self  = shift;
        my $other = shift;
        return 1 if $self == $other;
        return 0 if ref $other ne ref $self;
        return $self->name eq $other->name;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Administrator {
    use Moose;

    has 'admin_id' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'servers_admined_by_him' =>
        ( is => 'ro', isa => 'ArrayRef[Server]', default => sub { [] } );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package DHCPConfig {
    use Moose;

    has 'start_ip' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'end_ip'   => ( is => 'ro', isa => 'Str', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package FileServerconfig {
    use Moose;
    use HashMap;

    has '_user_id_to_quota' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );

    sub get_quota_for_user {
        my ( $self, $user_id ) = @_;
        #...
    }

    sub set_quota_for_user {
        my ( $self, $user_id, $quota ) = @_;
        #...
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ServerConfigSystem {
    use Moose;

    has 'servers' =>
        ( is => 'ro', isa => 'ArrayRef[Server]', default => sub { [] } );
    has 'admins' => (
        is      => 'ro',
        isa     => 'ArrayRef[Administrator]',
        default => sub { [] },
    );
    has 'DHCP_servers' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );
    has 'file_servers' =>
        ( is => 'ro', isa => 'HashMap', default => sub { HashMap->new() } );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $server1 = Server->new( name => 's1' );
my $admin1 = Administrator->new( admin_id => 'vijay' );
push @{ $admin1->servers_admined_by_him }, $server1;
my $dhcp = DHCPConfig->new( start_ip => '192.168.0.21',
    end_ip => '192.168.0.254' );
my $file_server = FileServerconfig->new();
my $sys = ServerConfigSystem->new();
push @{ $sys->servers }, $server1;
push @{ $sys->admins },  $admin1;
$sys->DHCP_servers->put( $server1, $dhcp );
$sys->file_servers->put( $server1, $file_server );
is( $sys->DHCP_servers->get($server1), $dhcp,        'DHCP server' );
is( $sys->file_servers->get($server1), $file_server, 'File server' );
done_testing();
1;
