use 5.026;
use warnings;
use utf8;

package NormalPayment {
    use Moose;
    use constant TAX_RATE => 0.1;
    has 'units' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'rate'  => ( is => 'ro', isa => 'Num', required => 1 );

    sub get_billable_amount {
        my $self     = shift;
        my $base_amt = $self->units * $self->rate;
        my $tax      = $base_amt * TAX_RATE;
        return $base_amt + $tax;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package PaymentForSeniorCitizen {
    use Moose;
    use constant TAX_RATE => 0.1;
    has 'units' => ( is => 'ro', isa => 'Int', required => 1 );
    has 'rate'  => ( is => 'ro', isa => 'Num', required => 1 );

    sub get_billable_amount {
        my $self     = shift;
        my $base_amt = $self->units * $self->rate * 0.8;
        my $tax      = $base_amt * ( TAX_RATE - 0.05 );
        return $base_amt + $tax;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $np = NormalPayment->new( units => 10, rate => 2 );
is( $np->get_billable_amount, 22 );
my $sp = PaymentForSeniorCitizen->new( units => 10, rate => 2 );
is( $sp->get_billable_amount, 16.8 );
done_testing();
1;
