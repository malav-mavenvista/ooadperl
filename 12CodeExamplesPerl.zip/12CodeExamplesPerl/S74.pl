use 5.026;
use warnings;
use utf8;

package IButton {
    use Moose::Role;
    requires 'paint';

    sub add_action_listener {
        my ( $self, $listener ) = @_;
        #...
        return $self;
    }
    no Moose::Role;
    1;
}

package LabelButton {
    use Moose;
    with 'IButton';
    has 'label_font' => ( is => 'rw', isa => 'Font' );
    has 'label_text' => ( is => 'rw', isa => 'Str', default => q{} );

    sub paint {
        my ( $self, $graphics ) = @_;
        #draw the label text on the graphics using the label's font.
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BitmapButton {
    use Moose;
    with 'IButton';
    has 'bitmap' => ( is => 'rw', isa => 'Bitmap' );

    sub paint {
        my ( $self, $graphics ) = @_;
        #draw the bitmap on the graphics.
        return $self;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $b = LabelButton->new();
$b->paint('Graphics absent for this demo');
my $bb = BitmapButton->new();
$bb->add_action_listener('listener absent for this demo');
$bb->paint('Graphics absent for this demo');
done_testing();
1;
