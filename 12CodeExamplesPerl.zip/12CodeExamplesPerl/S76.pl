use 5.026;
use warnings;
use utf8;

package PricingService {
    use Moose;
    use List::Util qw(sum0);

    has 'voucher_service' =>
        ( is => 'ro', isa => 'VoucherService', required => 1 );
    has 'price_calculation' =>
        ( is => 'ro', isa => 'IPriceCalculation', required => 1 );

    sub calculate_price {
        my ( $self, $shopping_basket, $user, $voucher ) = @_;
        my $discount = $self->calculate_discount($user);
        my $total    = sum0 map
        	{ $self->price_calculation->calculate_product_price( $_->product, $_->quanity ) }
        	@{ $shopping_basket->items() };
        $total += $self->apply_additional_discounts( $total, $user, $voucher );
        return $total * ( ( 100 - $discount ) / 100 );
    }

    sub calculate_discount {
        my ( $self, $user ) = @_;
        return $user->is_prime() ? 10 : 0;
    }

    sub apply_additional_discounts {
        my ( $self, $total, $user, $voucher ) = @_;
        my $voucher_value = $self->voucher_service->get_voucher_value($voucher);
        my $total_after_value = $total - $voucher_value;
        return $total_after_value > 0 ? $total_after_value : 0;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package IPriceCalculation {
    use Moose::Role;
    requires 'calculate_product_price';
    no Moose::Role;
    1;
}

package StandardPriceCalculation {
    use Moose;
    with 'IPriceCalculation';

    sub calculate_product_price {
        my ( $self, $product, $quantity ) = @_;
        return $product->price * $quantity;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package BoxingDayPriceCalculation {
    use Moose;
    with 'IPriceCalculation';
    use constant BOXING_DAY_DISCOUNT => 0.60;

    sub calculate_product_price {
        my ( $self, $product, $quantity ) = @_;
        return $product->price * $quantity * BOXING_DAY_DISCOUNT;
    }
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#To avoid compilation/execution error, the following empty classes are created.
package Product {
    use Moose;
    has 'price' => ( is => 'ro', isa => 'Num', required => 1 );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package VoucherService {
    use Moose;

    sub get_voucher_value {
        return 0;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package User {
    use Moose;

    sub is_prime {
        return 0;
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Item {
    use Moose;
    has 'product' => ( is => 'rw', isa => 'Product' );
    has 'quanity' => ( is => 'rw', isa => 'Num' );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ShoppingBasket {
    use Moose;
    has 'items' =>
        ( is => 'ro', isa => 'ArrayRef[Item]', default => sub { [] } );
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#end of empty classes

use Test::More;
my $spc = StandardPriceCalculation->new();
my $bpc = BoxingDayPriceCalculation->new();
my $ps  = PricingService->new(
    voucher_service   => VoucherService->new(),
    price_calculation => $spc
);
$ps->calculate_price( ShoppingBasket->new(), User->new(), q{} );
done_testing();
1;
