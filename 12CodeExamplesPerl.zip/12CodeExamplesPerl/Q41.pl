use 5.026;
use warnings;
use utf8;

# This application is concerned with training courses.
# A course has a title, a fee and a list of sessions. However,
# sometimes a course can consist of several modules, each of which is a
# course. For example, there may be a compound course "Fast track to
# becoming a web developer" which consists of three modules: a course
# named "HTML", a course named "FrontPage" and a course named "Flash".
# It is possible for a module to consist of some other modules.
# If a course consists of modules, its fee and schedule are totally
# determined by that of its modules and thus it will not maintain
# its list of sessions.
# Point out and remove the code smells in the code.

package Session {
    use Moose;
    use DateTime;

    has 'date'       => ( is => 'ro', isa => 'DateTime', required => 1 );
    has 'start_hour' => ( is => 'ro', isa => 'Int',      required => 1 );
    has 'end_hour'   => ( is => 'ro', isa => 'Int',      required => 1 );

    sub get_duration {
        my $self = shift;
        return $self->end_hour - $self->start_hour;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Course {
    use Moose;
    use Carp;
    use List::Util qw(sum0);

    has 'course_title' => ( is => 'ro', isa => 'Str', required => 1 );
    has 'sessions' =>
        ( is => 'ro', isa => 'ArrayRef[Session]', default => sub { [] } );

    has '_fee' => ( is => 'rw', isa => 'Num', default => 0, init_arg=>'course_fee' );
    	#The attribute _fee starts with underscore to indicate that it should not be used directly.
    	#We can  use get_fee and set_fee for the same.
    	#To enable passing the value to constructor, we have init_arg that doesn't start with underscore

    has 'modules' =>
        ( is => 'ro', isa => 'ArrayRef[Course]', default => sub { [] } );

    sub get_duration {
        my $self = shift;
        if ( scalar @{ $self->modules } == 0 ) {
            return sum0 map { $_->get_duration() } @{ $self->sessions };
        }
        return sum0 map { $_->get_duration() } @{ $self->modules };
    }

    sub get_fee {
        my $self = shift;
        return $self->_fee if ( scalar @{ $self->modules } == 0 );
        return sum0 map { $_->_fee } @{ $self->modules };

    }

    sub set_fee {
        my ( $self, $fee ) = @_;
        ( scalar @{ $self->modules } == 0 )
            or croak 'Please set the fee for each module one by one';
        $self->_fee = $fee;
        return $self;
    }

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $s1 = Session->new( date => DateTime->today, start_hour => 9,
    end_hour => 10 );
my $s2 = Session->new( date => DateTime->today, start_hour => 18,
    end_hour => 20 );

my $html = Course->new( course_title => 'html', course_fee => 100, sessions => [$s1] );
is( $html->get_duration, 1,   'Html duration' );
is( $html->get_fee,      100, 'Html fee' );

my $css = Course->new( course_title => 'css', course_fee => 75, sessions => [$s2] );
is( $css->get_duration, 2,  'Css duration' );
is( $css->get_fee,      75, 'Css fee' );

my $web = Course->new( course_title => 'web', modules => [ $html, $css ] );
is( $web->get_duration, 3,   'Web duration' );
is( $web->get_fee,      175, 'Web fee' );
done_testing();
1;
