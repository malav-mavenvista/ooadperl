use 5.026;
use warnings;
use utf8;
use Point;

package Shape {
    use Moose;

    has 'shape_type' => (
        traits   => ['Enumeration'],
        is       => 'ro',
        required => 1,
        enum     => [qw/ circle rect line /],
        handles  => 1,
    );

    #starting point of the line.
    #lower left corner of the rectangle.
    #center of the circle.
    has 'p1' => ( is => 'ro', isa => 'Point', required => 1 );

    #ending point of the line.
    #upper right corner of the rectangle.
    #not used for the circle.
    has 'p2' => ( is => 'rw', isa => 'Point' );

    has 'radius' => ( is => 'rw', isa => 'Int', default => 0 );

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package CADApp {
    use Moose;

    sub draw_shapes {
        my ( $self, $graphics, @shapes ) = @_;
        foreach my $shape (@shapes) {
            if ( $shape->is_line ) {
                $graphics->draw_line( $shape->p1, $shape->p2 );
            }
            elsif ( $shape->is_rect ) {
                $graphics->draw_line( $shape->p1, $shape->p2 );

                #draw remaining three edges;
            }
            elsif ( $shape->is_circle ) {
                $graphics->draw_circle( $shape->p1, shape->radius );
            }
        }
        return $self;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}
use Test::More;
my $ca     = CADApp->new();
my $p1     = Point->new( x => 1, y => 2 );
my $p2     = Point->new( x => 3, y => 5 );
my $s1     = Shape->new( shape_type => 'line', p1 => $p1, p2 => $p2 );
my $s2     = Shape->new( shape_type => 'circle', p1 => $p1, radius => 3 );
my $s3     = Shape->new( shape_type => 'rect', p1 => $p1, p2 => $p2 );
my @shapes = ( $s1, $s2, $s3 );
$ca->draw_shapes( 'graphics not present. Demo only', () );
done_testing();
1;
