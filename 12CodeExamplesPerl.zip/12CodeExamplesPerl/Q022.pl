use 5.026;
use warnings;
use utf8;

#Improve code
package Organization {
    use Moose;

    has 'id' => ( is => 'ro', isa => 'Str', required => 1 );

    has 'e_name' => ( is => 'rw', isa => 'Str', default => q{} ); #English name
    has 'c_name' => ( is => 'rw', isa => 'Str', default => q{} ); #Chinese name

    has 'tel_country_code' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'tel_area_code'    => ( is => 'rw', isa => 'Str', default => q{} );
    has 'tel_local_number' => ( is => 'rw', isa => 'Str', default => q{} );

    has 'fax_country_code' => ( is => 'rw', isa => 'Str', default => q{} );
    has 'fax_area_code'    => ( is => 'rw', isa => 'Str', default => q{} );
    has 'fax_local_number' => ( is => 'rw', isa => 'Str', default => q{} );

    has 'contact_person_e_first_name' => #First and last name in English
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_e_last_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    has 'contact_person_c_first_name' => #First and last name in Chinese
        ( is => 'rw', isa => 'Str', default => q{} )
        ;        has 'contact_person_c_last_name' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    has 'contact_person_tel_country_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_tel_area_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_tel_number' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    has 'contact_person_fax_country_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_fax_area_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_fax_local_number' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    has 'contact_person_mobile_country_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_mobile_area_code' =>
        ( is => 'rw', isa => 'Str', default => q{} );
    has 'contact_person_mobile_local_number' =>
        ( is => 'rw', isa => 'Str', default => q{} );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $p = Organization->new( id => 'Company' );
ok( defined $p, 'Organization object created' );
done_testing();
1;