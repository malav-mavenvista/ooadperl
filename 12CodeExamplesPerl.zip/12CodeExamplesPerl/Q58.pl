use 5.026;
use warnings;
use utf8;

# This application lets the network administrators document their
# server configurations.
# Originally we had a simple Server class as shown in the code:
package Server {
    use Moose;

    has 'name'            => ( is => 'ro', isa => 'Str', required => 1 );
    has 'cpu_model'       => ( is => 'rw', isa => 'Str', default  => q{} );
    has 'ram_size_in_GB'  => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'disk_size_in_GB' => ( is => 'rw', isa => 'Int', default  => 0 );
    has 'ip_address'      => ( is => 'rw', isa => 'Str', default  => q{} );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package ServerConfigSystem {
    use Moose;

    has '_servers' =>
        ( is => 'ro', isa => 'ArrayRef[Server]', default => sub { [] } );

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

#Now, there are four new requirements. You are required to implement
#these requirements without modifying the Server class:
# 1. An administrator (identified by an admin ID) can be assigned
#    to be responsible for a server.
# 2. We can check if a server is a DHCP server or not. If yes,
#    we can record the address scope it manages
#    (e.g., from 192.168.0.21 to 192.168.0.254).
# 3. We can check if a server is a file server or not. If yes, we can
#    set and check the disk space quota allocated for each user
#    (identified by a user ID).
# 4. A server can be a DHCP server and a file server at the same time.

use Test::More;
ok( defined Server->new( name => 's1' ), 'Server created' );
ok( defined ServerConfigSystem->new(), 'Server config system created' );
done_testing();
1;
