use 5.026;
use warnings;
use utf8;

package IPayment {
	use Moose::Role;
	requires 'pay';
	no Moose::Role;
	1;
}
1;