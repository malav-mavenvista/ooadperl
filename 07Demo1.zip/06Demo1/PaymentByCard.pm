use 5.026;
use warnings;
use utf8;

package PaymentByCard {
	use Moose::Role;
	use IPayment;
	requires 'get_card_number';
	sub pay {
		my ($self, $amount) =@_;
		#
		pay_by_card($self->get_card_number);
		#
	}
	sub pay_by_card { 
		#...
	}

	with 'IPayment';



	no Moose::Role;
	1;
}

1;