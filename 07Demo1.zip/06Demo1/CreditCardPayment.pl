use 5.026;
use warnings;
use utf8;

package CreditCardPayment {
	use Moose;
	use PaymentByCard;
	with 'PaymentByCard';

	has 'card_number' => (is=>'ro', isa=>'Int', required=>1);

	sub get_card_number {
		my $self = shift;
		return $self->card_number;
	}

    #Other attributes and methods here.
	__PACKAGE__->meta->make_immutable;
    no Moose;
	1;
}

use Test::More;
my $c = CreditCardPayment->new(card_number=>123);
$c->pay(100);
done_testing();
1;