use 5.026;
use warnings;
use utf8;

package Customer {
    use Moose;

    has 'name'    => ( is => 'ro', isa => 'Str' );
    has 'address' => ( is => 'rw', isa => 'Str', default => q{} );

    sub get_discount_info {
        return 0;    #code not shown here
    }

    #Other attributes and methods here.
    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Product {
    use Moose;

    sub get_pricing_details {
        return 0;    #code not shown here
    }

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package OrderLine {
    use Moose;

    has 'quantity' => ( is => 'ro', isa => 'Int',     default  => 1 );
    has 'product'  => ( is => 'ro', isa => 'Product', required => 1 );

    #Other attributes and methods here

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

package Order {
    use Moose;
    use List::Util qw(sum0);
    has 'customer' => ( is => 'ro', isa => 'Customer', required => 1 );
    has '_line_items' =>
        ( is => 'ro', isa => 'ArrayRef[OrderLine]', default => sub { [] } );

    sub calculate_base_price {
        return 0;    #code not shown here
    }

    sub calculate_discounts {
        my $self = shift;
        return $self->customer->get_discount_info();
    }

    sub calculate_price {
        my $self = shift;
        my $sum  = sum0 map { $_->product->get_pricing_details( $_->quantity ) }  @{ $self->_line_items };
        return $self->calculate_base_price + $sum - $self->calculate_discounts;
    }

    #Other attributes and methods here.

    no Moose;
    __PACKAGE__->meta->make_immutable;
    1;
}

use Test::More;
my $c = Customer->new( name => 'vi' );
my $o = Order->new( customer => $c );
is( $o->calculate_price, 0 );
done_testing();
1;